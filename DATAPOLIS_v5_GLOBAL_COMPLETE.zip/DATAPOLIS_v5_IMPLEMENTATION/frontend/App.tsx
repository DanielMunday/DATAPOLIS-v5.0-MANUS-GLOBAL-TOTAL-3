/**
 * DATAPOLIS v5.0 - Frontend Application (React 19 + Vite + Tailwind)
 * Interfaz de usuario para análisis territorial precesional
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import MapView from './pages/MapView';
import Analysis from './pages/Analysis';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import './App.css';

interface AppState {
  selectedProperty: any | null;
  analysisResults: any | null;
  loading: boolean;
  error: string | null;
}

export default function App() {
  const [state, setState] = useState<AppState>({
    selectedProperty: null,
    analysisResults: null,
    loading: false,
    error: null
  });

  const handlePropertySelect = (property: any) => {
    setState(prev => ({ ...prev, selectedProperty: property }));
  };

  const handleAnalysis = async (property: any) => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const response = await fetch('/api/analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(property)
      });

      if (!response.ok) throw new Error('Analysis failed');

      const results = await response.json();
      setState(prev => ({
        ...prev,
        analysisResults: results,
        loading: false
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Unknown error',
        loading: false
      }));
    }
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />

        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route
              path="/"
              element={<Dashboard state={state} onPropertySelect={handlePropertySelect} />}
            />
            <Route
              path="/map"
              element={<MapView state={state} onAnalysis={handleAnalysis} />}
            />
            <Route
              path="/analysis"
              element={<Analysis state={state} onAnalysis={handleAnalysis} />}
            />
            <Route
              path="/reports"
              element={<Reports state={state} />}
            />
            <Route
              path="/settings"
              element={<Settings />}
            />
          </Routes>
        </main>

        {state.loading && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              <p className="mt-4 text-gray-700">Analyzing...</p>
            </div>
          </div>
        )}

        {state.error && (
          <div className="fixed bottom-4 right-4 bg-red-500 text-white px-6 py-4 rounded-lg">
            {state.error}
          </div>
        )}
      </div>
    </Router>
  );
}
