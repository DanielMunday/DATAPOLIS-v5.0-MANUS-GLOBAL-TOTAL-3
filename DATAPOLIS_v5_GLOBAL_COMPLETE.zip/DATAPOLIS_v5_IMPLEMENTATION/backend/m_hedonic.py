"""
DATAPOLIS v5.0 - M-HED (Hedonic Pricing Module)
Modelos hedónicos espaciales con SAR, SEM, SDM
Integración completa con kernel precesional
"""

import numpy as np
import pandas as pd
from scipy import optimize, stats
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import warnings

warnings.filterwarnings('ignore')


@dataclass
class HedonicModel:
    """Modelo hedónico ajustado"""
    model_type: str  # 'OLS', 'SAR', 'SEM', 'SDM'
    coefficients: np.ndarray
    residuals: np.ndarray
    r_squared: float
    adjusted_r_squared: float
    aic: float
    bic: float
    log_likelihood: float
    rho: Optional[float] = None  # Para SAR/SEM/SDM
    lambda_param: Optional[float] = None  # Para SEM
    theta: Optional[np.ndarray] = None  # Para SDM


class SpatialWeightMatrix:
    """Matriz de pesos espaciales"""
    
    def __init__(self, locations: np.ndarray, bandwidth: float = 1000):
        """
        Crear matriz de pesos espaciales
        locations: array de (lat, lon)
        bandwidth: distancia máxima en metros
        """
        self.locations = locations
        self.bandwidth = bandwidth
        self.W = self._create_weight_matrix()
        self.W_normalized = self._normalize_weights()
    
    def _create_weight_matrix(self) -> np.ndarray:
        """Crear matriz de pesos basada en distancia"""
        n = len(self.locations)
        W = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                if i != j:
                    # Distancia Haversine
                    lat1, lon1 = self.locations[i]
                    lat2, lon2 = self.locations[j]
                    
                    R = 6371000  # Radio Tierra en metros
                    dlat = np.radians(lat2 - lat1)
                    dlon = np.radians(lon2 - lon1)
                    
                    a = np.sin(dlat/2)**2 + np.cos(np.radians(lat1)) * np.cos(np.radians(lat2)) * np.sin(dlon/2)**2
                    c = 2 * np.arcsin(np.sqrt(a))
                    distance = R * c
                    
                    # Peso inversamente proporcional a distancia
                    if distance <= self.bandwidth:
                        W[i, j] = 1 / (1 + distance / 1000)
        
        return W
    
    def _normalize_weights(self) -> np.ndarray:
        """Normalizar matriz de pesos (row-stochastic)"""
        row_sums = self.W.sum(axis=1)
        row_sums[row_sums == 0] = 1  # Evitar división por cero
        return self.W / row_sums[:, np.newaxis]


class HedonicEngine:
    """Motor de análisis hedónico espacial"""
    
    def __init__(self):
        self.models = {}
        self.feature_names = None
    
    def prepare_data(self, df: pd.DataFrame, 
                    dependent_var: str,
                    independent_vars: List[str],
                    locations: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Preparar datos para análisis hedónico"""
        
        # Extraer variables
        y = df[dependent_var].values
        X = df[independent_vars].values
        
        # Agregar constante
        X = np.column_stack([np.ones(len(X)), X])
        
        # Almacenar nombres de features
        self.feature_names = ['Intercept'] + independent_vars
        
        # Crear matriz de pesos espaciales
        W = SpatialWeightMatrix(locations).W_normalized
        
        return y, X, W
    
    def fit_ols(self, y: np.ndarray, X: np.ndarray) -> HedonicModel:
        """Ajustar modelo OLS (Ordinary Least Squares)"""
        
        # Estimación por mínimos cuadrados
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        
        # Predicciones y residuos
        y_pred = X @ beta
        residuals = y - y_pred
        
        # Estadísticas
        n = len(y)
        k = X.shape[1]
        
        ss_total = np.sum((y - np.mean(y))**2)
        ss_residual = np.sum(residuals**2)
        
        r_squared = 1 - (ss_residual / ss_total)
        adjusted_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k))
        
        # AIC y BIC
        sigma2 = ss_residual / (n - k)
        log_likelihood = -n/2 * np.log(2 * np.pi * sigma2) - ss_residual / (2 * sigma2)
        aic = 2 * k - 2 * log_likelihood
        bic = k * np.log(n) - 2 * log_likelihood
        
        return HedonicModel(
            model_type='OLS',
            coefficients=beta,
            residuals=residuals,
            r_squared=r_squared,
            adjusted_r_squared=adjusted_r_squared,
            aic=aic,
            bic=bic,
            log_likelihood=log_likelihood
        )
    
    def fit_sar(self, y: np.ndarray, X: np.ndarray, W: np.ndarray) -> HedonicModel:
        """
        Ajustar modelo SAR (Spatial Autoregressive)
        y = ρWy + Xβ + ε
        """
        
        n = len(y)
        k = X.shape[1]
        
        def log_likelihood(params):
            rho = params[0]
            beta = params[1:]
            
            # Matriz (I - ρW)
            I_rhoW = np.eye(n) - rho * W
            
            try:
                det_log = np.linalg.slogdet(I_rhoW)[1]
            except:
                return 1e10
            
            # Residuos transformados
            residuals = y - rho * W @ y - X @ beta
            
            # Log-likelihood
            sigma2 = np.sum(residuals**2) / n
            ll = det_log - n/2 * np.log(2 * np.pi * sigma2) - np.sum(residuals**2) / (2 * sigma2)
            
            return -ll
        
        # Inicialización
        beta_init = np.linalg.lstsq(X, y, rcond=None)[0]
        params_init = np.concatenate([[0.3], beta_init])
        
        # Optimización
        result = optimize.minimize(log_likelihood, params_init, method='Nelder-Mead')
        
        rho_est = result.x[0]
        beta_est = result.x[1:]
        
        # Residuos y estadísticas
        I_rhoW = np.eye(n) - rho_est * W
        residuals = y - rho_est * W @ y - X @ beta_est
        
        ss_total = np.sum((y - np.mean(y))**2)
        ss_residual = np.sum(residuals**2)
        
        r_squared = 1 - (ss_residual / ss_total)
        adjusted_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
        
        sigma2 = ss_residual / (n - k - 1)
        det_log = np.linalg.slogdet(I_rhoW)[1]
        log_likelihood = det_log - n/2 * np.log(2 * np.pi * sigma2) - ss_residual / (2 * sigma2)
        
        aic = 2 * (k + 1) - 2 * log_likelihood
        bic = (k + 1) * np.log(n) - 2 * log_likelihood
        
        return HedonicModel(
            model_type='SAR',
            coefficients=beta_est,
            residuals=residuals,
            r_squared=r_squared,
            adjusted_r_squared=adjusted_r_squared,
            aic=aic,
            bic=bic,
            log_likelihood=log_likelihood,
            rho=rho_est
        )
    
    def fit_sem(self, y: np.ndarray, X: np.ndarray, W: np.ndarray) -> HedonicModel:
        """
        Ajustar modelo SEM (Spatial Error Model)
        y = Xβ + u, donde u = λWu + ε
        """
        
        n = len(y)
        k = X.shape[1]
        
        def log_likelihood(params):
            beta = params[:-1]
            lambda_param = params[-1]
            
            # Matriz (I - λW)
            I_lambdaW = np.eye(n) - lambda_param * W
            
            try:
                det_log = np.linalg.slogdet(I_lambdaW)[1]
            except:
                return 1e10
            
            # Residuos
            residuals = y - X @ beta
            
            # Log-likelihood
            sigma2 = np.sum(residuals**2) / n
            ll = det_log - n/2 * np.log(2 * np.pi * sigma2) - np.sum(residuals**2) / (2 * sigma2)
            
            return -ll
        
        # Inicialización
        beta_init = np.linalg.lstsq(X, y, rcond=None)[0]
        params_init = np.concatenate([beta_init, [0.3]])
        
        # Optimización
        result = optimize.minimize(log_likelihood, params_init, method='Nelder-Mead')
        
        beta_est = result.x[:-1]
        lambda_est = result.x[-1]
        
        # Residuos y estadísticas
        residuals = y - X @ beta_est
        
        ss_total = np.sum((y - np.mean(y))**2)
        ss_residual = np.sum(residuals**2)
        
        r_squared = 1 - (ss_residual / ss_total)
        adjusted_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
        
        sigma2 = ss_residual / (n - k - 1)
        I_lambdaW = np.eye(n) - lambda_est * W
        det_log = np.linalg.slogdet(I_lambdaW)[1]
        log_likelihood = det_log - n/2 * np.log(2 * np.pi * sigma2) - ss_residual / (2 * sigma2)
        
        aic = 2 * (k + 1) - 2 * log_likelihood
        bic = (k + 1) * np.log(n) - 2 * log_likelihood
        
        return HedonicModel(
            model_type='SEM',
            coefficients=beta_est,
            residuals=residuals,
            r_squared=r_squared,
            adjusted_r_squared=adjusted_r_squared,
            aic=aic,
            bic=bic,
            log_likelihood=log_likelihood,
            lambda_param=lambda_est
        )
    
    def fit_sdm(self, y: np.ndarray, X: np.ndarray, W: np.ndarray) -> HedonicModel:
        """
        Ajustar modelo SDM (Spatial Durbin Model)
        y = ρWy + Xβ + WXθ + ε
        """
        
        n = len(y)
        k = X.shape[1]
        
        # Crear matriz de variables espacialmente rezagadas
        WX = W @ X
        X_augmented = np.column_stack([X, WX])
        
        def log_likelihood(params):
            rho = params[0]
            beta_theta = params[1:]
            
            # Matriz (I - ρW)
            I_rhoW = np.eye(n) - rho * W
            
            try:
                det_log = np.linalg.slogdet(I_rhoW)[1]
            except:
                return 1e10
            
            # Residuos
            residuals = y - rho * W @ y - X_augmented @ beta_theta
            
            # Log-likelihood
            sigma2 = np.sum(residuals**2) / n
            ll = det_log - n/2 * np.log(2 * np.pi * sigma2) - np.sum(residuals**2) / (2 * sigma2)
            
            return -ll
        
        # Inicialización
        beta_init = np.linalg.lstsq(X_augmented, y, rcond=None)[0]
        params_init = np.concatenate([[0.3], beta_init])
        
        # Optimización
        result = optimize.minimize(log_likelihood, params_init, method='Nelder-Mead')
        
        rho_est = result.x[0]
        beta_theta_est = result.x[1:]
        
        # Separar β y θ
        beta_est = beta_theta_est[:k]
        theta_est = beta_theta_est[k:]
        
        # Residuos y estadísticas
        I_rhoW = np.eye(n) - rho_est * W
        residuals = y - rho_est * W @ y - X_augmented @ beta_theta_est
        
        ss_total = np.sum((y - np.mean(y))**2)
        ss_residual = np.sum(residuals**2)
        
        r_squared = 1 - (ss_residual / ss_total)
        adjusted_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - 2*k - 1))
        
        sigma2 = ss_residual / (n - 2*k - 1)
        det_log = np.linalg.slogdet(I_rhoW)[1]
        log_likelihood = det_log - n/2 * np.log(2 * np.pi * sigma2) - ss_residual / (2 * sigma2)
        
        aic = 2 * (2*k + 1) - 2 * log_likelihood
        bic = (2*k + 1) * np.log(n) - 2 * log_likelihood
        
        return HedonicModel(
            model_type='SDM',
            coefficients=beta_est,
            residuals=residuals,
            r_squared=r_squared,
            adjusted_r_squared=adjusted_r_squared,
            aic=aic,
            bic=bic,
            log_likelihood=log_likelihood,
            rho=rho_est,
            theta=theta_est
        )
    
    def calculate_morans_i(self, residuals: np.ndarray, W: np.ndarray) -> Dict:
        """Calcular índice de Moran I para autocorrelación espacial"""
        
        n = len(residuals)
        mean = np.mean(residuals)
        deviations = residuals - mean
        
        # Numerador: suma de productos cruzados ponderados
        numerator = np.sum(W * np.outer(deviations, deviations))
        
        # Denominador: suma de desviaciones cuadradas
        denominator = np.sum(deviations ** 2)
        
        # Moran's I
        morans_i = (n / np.sum(W)) * (numerator / denominator)
        
        # Significancia
        expected_i = -1 / (n - 1)
        variance = self._calculate_variance_morans_i(W, deviations)
        z_score = (morans_i - expected_i) / np.sqrt(variance)
        p_value = 2 * (1 - stats.norm.cdf(np.abs(z_score)))
        
        return {
            'morans_i': morans_i,
            'expected_i': expected_i,
            'variance': variance,
            'z_score': z_score,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
    
    def _calculate_variance_morans_i(self, W: np.ndarray, deviations: np.ndarray) -> float:
        """Calcular varianza de Moran's I"""
        n = len(deviations)
        
        # Suma de pesos
        S0 = np.sum(W)
        
        # Suma de pesos al cuadrado
        S1 = 0.5 * np.sum((W + W.T)**2)
        
        # Suma de pesos por filas y columnas
        S2 = np.sum(np.sum(W, axis=1)**2)
        
        # Momento de cuarto orden
        b2 = np.sum(deviations**4) / (n * (np.sum(deviations**2) / n)**2)
        
        # Varianza
        variance = (n * ((n**2 - 3*n + 3) * S1 - n * S2 + 3 * S0**2) - 
                   b2 * ((n**2 - n) * S1 - 2*n * S2 + 6 * S0**2)) / (
                   (n - 1) * (n - 2) * (n - 3) * S0**2)
        
        return variance
    
    def predict(self, model: HedonicModel, X_new: np.ndarray) -> np.ndarray:
        """Hacer predicciones con modelo ajustado"""
        return X_new @ model.coefficients
    
    def summary(self, model: HedonicModel) -> str:
        """Generar resumen del modelo"""
        
        summary = f"""
{'='*60}
RESUMEN DEL MODELO HEDÓNICO - {model.model_type}
{'='*60}

ESTADÍSTICAS GENERALES:
  R-squared: {model.r_squared:.4f}
  R-squared ajustado: {model.adjusted_r_squared:.4f}
  AIC: {model.aic:.2f}
  BIC: {model.bic:.2f}
  Log-likelihood: {model.log_likelihood:.2f}

COEFICIENTES:
"""
        
        for i, name in enumerate(self.feature_names):
            summary += f"  {name:20s}: {model.coefficients[i]:10.4f}\n"
        
        if model.rho is not None:
            summary += f"\n  ρ (Autocorrelación espacial): {model.rho:.4f}\n"
        
        if model.lambda_param is not None:
            summary += f"  λ (Autocorrelación en errores): {model.lambda_param:.4f}\n"
        
        if model.theta is not None:
            summary += f"\n  EFECTOS INDIRECTOS (θ):\n"
            for i, name in enumerate(self.feature_names[1:]):
                summary += f"    {name:20s}: {model.theta[i]:.4f}\n"
        
        summary += f"\n{'='*60}\n"
        
        return summary


# Ejemplo de uso
if __name__ == "__main__":
    # Crear datos de ejemplo
    np.random.seed(42)
    n = 100
    
    # Ubicaciones
    locations = np.random.uniform([-33.5, -70.7], [-33.4, -70.6], (n, 2))
    
    # Variables independientes
    df = pd.DataFrame({
        'area_sqm': np.random.uniform(100, 500, n),
        'age_years': np.random.uniform(0, 50, n),
        'bedrooms': np.random.randint(1, 5, n),
        'bathrooms': np.random.randint(1, 4, n),
        'parking': np.random.randint(0, 3, n)
    })
    
    # Variable dependiente (valor m²)
    df['value_per_sqm'] = (3000 + 
                          10 * df['area_sqm'] + 
                          -50 * df['age_years'] + 
                          500 * df['bedrooms'] + 
                          300 * df['bathrooms'] + 
                          200 * df['parking'] + 
                          np.random.normal(0, 500, n))
    
    # Crear motor
    engine = HedonicEngine()
    
    # Preparar datos
    y, X, W = engine.prepare_data(
        df, 
        'value_per_sqm',
        ['area_sqm', 'age_years', 'bedrooms', 'bathrooms', 'parking'],
        locations
    )
    
    # Ajustar modelos
    print("Ajustando modelos hedónicos...\n")
    
    model_ols = engine.fit_ols(y, X)
    print(engine.summary(model_ols))
    
    model_sar = engine.fit_sar(y, X, W)
    print(engine.summary(model_sar))
    
    model_sem = engine.fit_sem(y, X, W)
    print(engine.summary(model_sem))
    
    model_sdm = engine.fit_sdm(y, X, W)
    print(engine.summary(model_sdm))
    
    # Calcular Moran's I
    morans = engine.calculate_morans_i(model_ols.residuals, W)
    print(f"\nMoran's I (OLS residuals): {morans['morans_i']:.4f}")
    print(f"p-value: {morans['p_value']:.4f}")
    print(f"Significativo: {morans['significant']}")
