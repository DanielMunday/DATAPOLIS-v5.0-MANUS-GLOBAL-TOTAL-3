<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - PAE M11 - MIGRACIONES
 * Tablas del Motor de Análisis Precesional
 * =========================================================================
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // =====================================================================
        // TABLA: precession_analyses
        // Almacena resultados de análisis precesionales
        // =====================================================================
        if (!Schema::hasTable('precession_analyses')) {
            Schema::create('precession_analyses', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
                $table->foreignId('copropiedad_id')->constrained('copropiedades')->onDelete('cascade');
                
                // Tipo y estado
                $table->string('analysis_type', 20)->default('full'); // quick, full, deep
                $table->string('status', 20)->default('pending'); // pending, processing, completed, failed
                
                // Parámetros de entrada
                $table->json('parameters')->nullable();
                
                // Scores principales (0-100)
                $table->decimal('precession_score', 5, 2)->nullable()->comment('Score de precesión económica');
                $table->decimal('risk_score', 5, 2)->nullable()->comment('Score de riesgo');
                $table->decimal('opportunity_score', 5, 2)->nullable()->comment('Score de oportunidad');
                $table->decimal('confidence', 5, 2)->nullable()->comment('Nivel de confianza del análisis');
                
                // Valoración en UF
                $table->decimal('total_precession_value_uf', 14, 4)->nullable()->comment('Valor total precesional');
                $table->decimal('direct_value_uf', 14, 4)->nullable()->comment('Valor de efectos directos');
                $table->decimal('induced_value_uf', 14, 4)->nullable()->comment('Valor de efectos inducidos');
                $table->decimal('precession_value_uf', 14, 4)->nullable()->comment('Valor de efectos precesionales');
                $table->decimal('systemic_value_uf', 14, 4)->nullable()->comment('Valor de efectos sistémicos');
                $table->decimal('counter_value_uf', 14, 4)->nullable()->comment('Valor de contra-efectos');
                
                // Resumen de efectos
                $table->json('effects_summary')->nullable()->comment('Resumen de efectos por tipo');
                $table->unsignedInteger('effects_count')->default(0)->comment('Cantidad total de efectos');
                
                // Performance
                $table->unsignedInteger('execution_time_ms')->nullable()->comment('Tiempo de ejecución en ms');
                $table->timestamp('expires_at')->nullable()->comment('Fecha de expiración del cache');
                
                // Sincronización con ÁGORA
                $table->boolean('synced_to_agora')->default(false);
                $table->timestamp('synced_at')->nullable();
                $table->string('agora_sync_id')->nullable();
                
                $table->timestamps();
                
                // Índices
                $table->index(['copropiedad_id', 'status', 'created_at']);
                $table->index(['tenant_id', 'created_at']);
                $table->index('expires_at');
            });
        }

        // =====================================================================
        // TABLA: precession_alerts
        // Alertas generadas por el análisis precesional
        // =====================================================================
        if (!Schema::hasTable('precession_alerts')) {
            Schema::create('precession_alerts', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
                $table->foreignId('copropiedad_id')->constrained('copropiedades')->onDelete('cascade');
                $table->uuid('precession_analysis_id')->nullable();
                
                // Clasificación
                $table->string('alert_type', 50)->comment('Tipo de alerta');
                $table->enum('severity', ['info', 'warning', 'high', 'critical'])->default('warning');
                
                // Contenido
                $table->string('title', 200);
                $table->text('description');
                
                // Métricas de la alerta
                $table->decimal('probability', 5, 2)->nullable()->comment('Probabilidad de ocurrencia (0-100)');
                $table->decimal('potential_impact_uf', 14, 4)->nullable()->comment('Impacto potencial en UF');
                $table->unsignedSmallInteger('expected_months')->nullable()->comment('Meses esperados para materialización');
                
                // Acciones recomendadas
                $table->json('recommended_actions')->nullable();
                
                // Estado
                $table->enum('status', ['active', 'acknowledged', 'resolved', 'dismissed'])->default('active');
                $table->timestamp('resolved_at')->nullable();
                $table->foreignId('resolved_by')->nullable()->constrained('users');
                $table->text('resolution_notes')->nullable();
                
                // Metadata adicional
                $table->json('metadata')->nullable();
                
                // Sincronización
                $table->boolean('synced_to_agora')->default(false);
                
                $table->timestamps();
                
                // Índices
                $table->index(['copropiedad_id', 'status', 'severity']);
                $table->index(['tenant_id', 'status']);
                $table->index(['alert_type', 'status']);
                
                // Foreign key
                $table->foreign('precession_analysis_id')
                    ->references('id')
                    ->on('precession_analyses')
                    ->onDelete('set null');
            });
        }

        // =====================================================================
        // TABLA: precession_effects
        // Efectos individuales detectados (opcional, para análisis detallado)
        // =====================================================================
        if (!Schema::hasTable('precession_effects')) {
            Schema::create('precession_effects', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->uuid('precession_analysis_id');
                
                // Clasificación del efecto
                $table->string('effect_type', 30); // direct, induced, precession, systemic, counter
                $table->unsignedTinyInteger('depth')->default(1)->comment('Profundidad en el grafo (1-4)');
                
                // Nodos origen y destino
                $table->string('source_node_type', 50);
                $table->unsignedBigInteger('source_node_id');
                $table->string('target_node_type', 50);
                $table->unsignedBigInteger('target_node_id');
                
                // Relación
                $table->string('edge_type', 50)->comment('Tipo de arista en la ontología');
                
                // Valoración
                $table->decimal('weight', 8, 4)->default(0)->comment('Peso del efecto (-100 a 100)');
                $table->decimal('value_uf', 14, 4)->nullable()->comment('Valor monetario del efecto');
                
                // Metadata
                $table->json('attributes')->nullable();
                
                $table->timestamps();
                
                // Índices
                $table->index('precession_analysis_id');
                $table->index(['effect_type', 'depth']);
                
                // Foreign key
                $table->foreign('precession_analysis_id')
                    ->references('id')
                    ->on('precession_analyses')
                    ->onDelete('cascade');
            });
        }

        // =====================================================================
        // TABLA: precession_simulations
        // Resultados de simulaciones what-if
        // =====================================================================
        if (!Schema::hasTable('precession_simulations')) {
            Schema::create('precession_simulations', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
                $table->foreignId('copropiedad_id')->constrained('copropiedades')->onDelete('cascade');
                $table->foreignId('user_id')->constrained()->comment('Usuario que ejecutó la simulación');
                
                // Escenario
                $table->string('scenario_name', 100);
                $table->json('scenario_parameters');
                
                // Resultados comparativos
                $table->json('baseline_scores')->comment('Scores antes de la simulación');
                $table->json('simulated_scores')->comment('Scores simulados');
                $table->json('delta_scores')->comment('Diferencias');
                
                // Valoración
                $table->decimal('baseline_value_uf', 14, 4);
                $table->decimal('simulated_value_uf', 14, 4);
                $table->decimal('delta_value_uf', 14, 4);
                
                // Recomendación
                $table->text('recommendation')->nullable();
                $table->enum('recommendation_type', ['favorable', 'neutral', 'unfavorable'])->nullable();
                
                $table->timestamps();
                
                // Índices
                $table->index(['copropiedad_id', 'created_at']);
                $table->index(['user_id', 'created_at']);
            });
        }

        // =====================================================================
        // TABLA: precession_ontology_nodes
        // Nodos de la ontología (para referencia)
        // =====================================================================
        if (!Schema::hasTable('precession_ontology_nodes')) {
            Schema::create('precession_ontology_nodes', function (Blueprint $table) {
                $table->id();
                $table->string('node_type', 50)->unique();
                $table->string('label', 100);
                $table->text('description')->nullable();
                $table->json('attributes_schema')->nullable()->comment('Schema de atributos esperados');
                $table->boolean('active')->default(true);
                $table->timestamps();
            });
        }

        // =====================================================================
        // TABLA: precession_ontology_edges
        // Aristas de la ontología (para referencia)
        // =====================================================================
        if (!Schema::hasTable('precession_ontology_edges')) {
            Schema::create('precession_ontology_edges', function (Blueprint $table) {
                $table->id();
                $table->string('edge_type', 50)->unique();
                $table->string('label', 100);
                $table->text('description')->nullable();
                $table->string('source_node_type', 50);
                $table->string('target_node_type', 50);
                $table->decimal('default_weight', 5, 2)->default(1);
                $table->boolean('active')->default(true);
                $table->timestamps();
                
                // Foreign keys
                $table->foreign('source_node_type')
                    ->references('node_type')
                    ->on('precession_ontology_nodes');
                $table->foreign('target_node_type')
                    ->references('node_type')
                    ->on('precession_ontology_nodes');
            });
        }

        // =====================================================================
        // TABLA: agora_sync_logs
        // Logs de sincronización con ÁGORA
        // =====================================================================
        if (!Schema::hasTable('agora_sync_logs')) {
            Schema::create('agora_sync_logs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
                $table->string('entity_type', 50); // analysis, alert, territorial_data
                $table->string('entity_id', 50);
                $table->enum('direction', ['push', 'pull']);
                $table->enum('status', ['pending', 'success', 'failed']);
                $table->json('request_payload')->nullable();
                $table->json('response_payload')->nullable();
                $table->text('error_message')->nullable();
                $table->unsignedInteger('execution_time_ms')->nullable();
                $table->timestamp('executed_at')->nullable();
                $table->timestamps();
                
                $table->index(['entity_type', 'entity_id']);
                $table->index(['tenant_id', 'status', 'created_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agora_sync_logs');
        Schema::dropIfExists('precession_ontology_edges');
        Schema::dropIfExists('precession_ontology_nodes');
        Schema::dropIfExists('precession_simulations');
        Schema::dropIfExists('precession_effects');
        Schema::dropIfExists('precession_alerts');
        Schema::dropIfExists('precession_analyses');
    }
};
