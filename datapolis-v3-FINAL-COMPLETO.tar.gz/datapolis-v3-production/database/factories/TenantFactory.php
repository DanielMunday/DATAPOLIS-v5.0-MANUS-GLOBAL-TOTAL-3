<?php

namespace Database\Factories;

use App\Models\Tenant;
use Illuminate\Database\Eloquent\Factories\Factory;

class TenantFactory extends Factory
{
    protected $model = Tenant::class;

    public function definition(): array
    {
        return [
            'uuid' => fake()->uuid(),
            'nombre' => fake()->company(),
            'rut' => '76' . fake()->numerify('#######') . '-' . fake()->randomElement(['0','1','2','3','4','5','6','7','8','9','K']),
            'slug' => fake()->unique()->slug(2),
            'email' => fake()->companyEmail(),
            'telefono' => fake()->phoneNumber(),
            'plan' => fake()->randomElement(['starter', 'professional', 'enterprise']),
            'activo' => true,
        ];
    }
}
