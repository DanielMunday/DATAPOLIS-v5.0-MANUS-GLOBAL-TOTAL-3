#!/bin/bash
#===============================================================================
# DATAPOLIS v3.0 - SCRIPT DE INSTALACIÓN AUTOMATIZADA
# Para servidores cPanel y VPS
#===============================================================================

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║          DATAPOLIS v3.0 - INSTALACIÓN AUTOMATIZADA             ║"
echo "╚════════════════════════════════════════════════════════════════╝"

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Verificar requisitos
echo -e "\n${YELLOW}[1/8] Verificando requisitos...${NC}"

if ! command -v php &> /dev/null; then
    echo -e "${RED}Error: PHP no está instalado${NC}"
    exit 1
fi

PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
echo "PHP Version: $PHP_VERSION"

if ! command -v composer &> /dev/null; then
    echo -e "${YELLOW}Instalando Composer...${NC}"
    curl -sS https://getcomposer.org/installer | php
    mv composer.phar /usr/local/bin/composer 2>/dev/null || mv composer.phar ./composer
    COMPOSER="./composer"
else
    COMPOSER="composer"
fi

# Configurar .env si no existe
echo -e "\n${YELLOW}[2/8] Configurando entorno...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}Archivo .env creado${NC}"
else
    echo -e "${GREEN}Archivo .env ya existe${NC}"
fi

# Instalar dependencias
echo -e "\n${YELLOW}[3/8] Instalando dependencias...${NC}"
$COMPOSER install --no-dev --optimize-autoloader --no-interaction

# Generar key
echo -e "\n${YELLOW}[4/8] Generando Application Key...${NC}"
php artisan key:generate --force

# Permisos
echo -e "\n${YELLOW}[5/8] Configurando permisos...${NC}"
chmod -R 755 storage bootstrap/cache
chmod -R 775 storage/logs
chmod -R 775 storage/framework

# Migraciones
echo -e "\n${YELLOW}[6/8] Ejecutando migraciones...${NC}"
echo "¿Ejecutar migraciones? (s/n): "
read -r MIGRATE
if [ "$MIGRATE" = "s" ] || [ "$MIGRATE" = "S" ]; then
    php artisan migrate --force
    echo -e "${GREEN}Migraciones ejecutadas${NC}"
fi

# Seeders
echo -e "\n${YELLOW}[7/8] Ejecutando seeders...${NC}"
echo "¿Ejecutar seeders? (s/n): "
read -r SEED
if [ "$SEED" = "s" ] || [ "$SEED" = "S" ]; then
    php artisan db:seed --force
    echo -e "${GREEN}Seeders ejecutados${NC}"
fi

# Optimizar
echo -e "\n${YELLOW}[8/8] Optimizando para producción...${NC}"
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Storage link
php artisan storage:link 2>/dev/null || true

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║              INSTALACIÓN COMPLETADA                            ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║                                                                ║"
echo "║  Usuario Admin:                                                ║"
echo "║    Email: admin@datapolis.cl                                   ║"
echo "║    Password: DataPolis2024!                                    ║"
echo "║                                                                ║"
echo "║  Próximos pasos:                                               ║"
echo "║  1. Configurar base de datos en .env                           ║"
echo "║  2. Ejecutar: php artisan migrate --force                      ║"
echo "║  3. Ejecutar: php artisan db:seed --force                      ║"
echo "║  4. Configurar cron para scheduler                             ║"
echo "║                                                                ║"
echo "║  Documentación: /docs/GUIA_INSTALACION_CPANEL.md               ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
