<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Copropiedad' => 'App\Policies\CopropiedadPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        // Super Admin bypasses all gates
        Gate::before(function ($user, $ability) {
            if ($user->hasRole('super-admin')) {
                return true;
            }
        });

        // Define gates for common operations
        Gate::define('manage-copropiedades', function ($user) {
            return $user->hasAnyPermission(['copropiedades.create', 'copropiedades.edit', 'copropiedades.delete']);
        });

        Gate::define('manage-antenas', function ($user) {
            return $user->hasAnyPermission(['antenas.create', 'antenas.facturar']);
        });

        Gate::define('manage-contabilidad', function ($user) {
            return $user->hasAnyPermission(['contabilidad.asientos', 'contabilidad.aprobar', 'contabilidad.cerrar']);
        });

        Gate::define('view-pae', function ($user) {
            return $user->hasPermissionTo('pae.view');
        });

        Gate::define('run-pae-analysis', function ($user) {
            return $user->hasPermissionTo('pae.analyze');
        });
    }
}
