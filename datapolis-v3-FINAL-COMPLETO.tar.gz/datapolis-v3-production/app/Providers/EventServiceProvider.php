<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

        // Eventos de Facturación de Antenas
        'App\Events\FacturaAntenaEmitida' => [
            'App\Listeners\ContabilizarFacturaAntena',
            'App\Listeners\DistribuirIngresoAntena',
            'App\Listeners\EnviarFacturaASii',
        ],

        // Eventos de Gastos Comunes
        'App\Events\PeriodoProrateado' => [
            'App\Listeners\NotificarCobrosCopropietarios',
            'App\Listeners\ActualizarMorosidades',
        ],

        // Eventos de Pagos
        'App\Events\PagoRegistrado' => [
            'App\Listeners\ContabilizarPago',
            'App\Listeners\ActualizarMorosidadUnidad',
        ],

        // Eventos PAE
        'App\Events\AnalisisPaeCompletado' => [
            'App\Listeners\SincronizarConAgora',
            'App\Listeners\NotificarAlertasCriticas',
        ],

        // Eventos de Compliance
        'App\Events\EvaluacionComplianceCompletada' => [
            'App\Listeners\NotificarBrechasCriticas',
        ],
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        //
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
