<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Eloquent\Model;
use App\Services\PAE\{PrecessionGraphEngine, PrecessionScoringEngine, PrecessionAlertEngine, PrecessionSyncService};
use App\Services\{ContabilidadService, AntenasFacturacionService, GastosComunesService, CertificadosTributariosService, ComplianceService, PrecessionService};

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // PAE Engines
        $this->app->singleton(PrecessionGraphEngine::class);
        $this->app->singleton(PrecessionScoringEngine::class);
        $this->app->singleton(PrecessionAlertEngine::class);
        $this->app->singleton(PrecessionSyncService::class);
        $this->app->singleton(PrecessionService::class);

        // Business Services
        $this->app->singleton(ContabilidadService::class);
        $this->app->singleton(AntenasFacturacionService::class);
        $this->app->singleton(GastosComunesService::class);
        $this->app->singleton(CertificadosTributariosService::class);
        $this->app->singleton(ComplianceService::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Set default string length for MySQL < 5.7.7
        Schema::defaultStringLength(191);

        // Strict mode for Eloquent in development
        Model::shouldBeStrict(!$this->app->isProduction());

        // Prevent lazy loading in development
        Model::preventLazyLoading(!$this->app->isProduction());
    }
}
