<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - PAE M11 - PRECESSION CONTROLLER
 * API REST para Motor de Análisis Precesional
 * =========================================================================
 */

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\PrecessionService;
use App\Models\{PrecessionAnalysis, PrecessionAlert, Copropiedad};
use Illuminate\Http\{Request, JsonResponse};
use Illuminate\Support\Facades\{Validator, Cache};

class PrecessionController extends Controller
{
    protected PrecessionService $precessionService;

    public function __construct(PrecessionService $precessionService)
    {
        $this->precessionService = $precessionService;
    }

    /**
     * GET /api/v1/copropiedades/{id}/pae/analysis
     * Ejecutar análisis precesional completo
     */
    public function analyze(Request $request, int $copropiedadId): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'horizon' => 'nullable|integer|min:6|max:120',
            'depth' => 'nullable|integer|min:1|max:6',
            'type' => 'nullable|in:quick,full,deep',
            'force_refresh' => 'nullable|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Parámetros inválidos',
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            // Verificar acceso a la copropiedad
            $copropiedad = Copropiedad::where('id', $copropiedadId)
                ->where('tenant_id', auth()->user()->tenant_id)
                ->firstOrFail();

            // Si no es force_refresh, intentar obtener del cache
            if (!$request->boolean('force_refresh')) {
                $cached = $this->getCachedAnalysis($copropiedadId);
                if ($cached) {
                    return response()->json([
                        'success' => true,
                        'message' => 'Análisis obtenido de cache',
                        'data' => $cached,
                        'cached' => true,
                    ]);
                }
            }

            $params = $validator->validated();
            $analysis = $this->precessionService->analyzeCopropiedad($copropiedadId, $params);

            return response()->json([
                'success' => true,
                'message' => 'Análisis precesional completado',
                'data' => $this->formatAnalysisResponse($analysis),
                'cached' => false,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error ejecutando análisis',
                'error' => config('app.debug') ? $e->getMessage() : 'Error interno',
            ], 500);
        }
    }

    /**
     * GET /api/v1/copropiedades/{id}/pae/quick
     * Análisis rápido (cached)
     */
    public function quickAnalysis(int $copropiedadId): JsonResponse
    {
        try {
            $result = $this->precessionService->quickAnalysis($copropiedadId);

            return response()->json([
                'success' => true,
                'data' => $result,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error en análisis rápido',
                'error' => config('app.debug') ? $e->getMessage() : 'Error interno',
            ], 500);
        }
    }

    /**
     * GET /api/v1/copropiedades/{id}/pae/history
     * Historial de análisis
     */
    public function history(Request $request, int $copropiedadId): JsonResponse
    {
        $limit = $request->input('limit', 10);

        $analyses = PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
            ->where('tenant_id', auth()->user()->tenant_id)
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $analyses->map(fn($a) => [
                'id' => $a->id,
                'date' => $a->created_at->toIso8601String(),
                'type' => $a->analysis_type,
                'status' => $a->status,
                'scores' => [
                    'precession' => $a->precession_score,
                    'risk' => $a->risk_score,
                    'opportunity' => $a->opportunity_score,
                    'confidence' => $a->confidence,
                ],
                'valuation_uf' => $a->total_precession_value_uf,
                'execution_time_ms' => $a->execution_time_ms,
            ]),
        ]);
    }

    /**
     * GET /api/v1/copropiedades/{id}/pae/projection
     * Proyección temporal
     */
    public function projection(Request $request, int $copropiedadId): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'months' => 'nullable|integer|min:1|max:60',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            $months = $request->input('months', 12);
            $projection = $this->precessionService->projectEffects($copropiedadId, $months);

            return response()->json([
                'success' => true,
                'data' => $projection,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error generando proyección',
                'error' => config('app.debug') ? $e->getMessage() : 'Error interno',
            ], 500);
        }
    }

    /**
     * POST /api/v1/copropiedades/{id}/pae/simulate
     * Simulación de escenarios
     */
    public function simulate(Request $request, int $copropiedadId): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'scenario' => 'required|array',
            'scenario.new_antenna_contract' => 'nullable|array',
            'scenario.new_antenna_contract.canon_uf' => 'required_with:scenario.new_antenna_contract|numeric|min:0',
            'scenario.reduce_delinquency_percent' => 'nullable|numeric|min:0|max:100',
            'scenario.new_units' => 'nullable|integer|min:0',
            'scenario.reserve_fund_increase_uf' => 'nullable|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            $result = $this->precessionService->simulateScenario(
                $copropiedadId, 
                $request->input('scenario')
            );

            return response()->json([
                'success' => true,
                'data' => $result,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error en simulación',
                'error' => config('app.debug') ? $e->getMessage() : 'Error interno',
            ], 500);
        }
    }

    /**
     * POST /api/v1/pae/compare
     * Comparar múltiples copropiedades
     */
    public function compare(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'copropiedad_ids' => 'required|array|min:2|max:10',
            'copropiedad_ids.*' => 'integer|exists:copropiedades,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            // Verificar acceso a todas las copropiedades
            $tenantId = auth()->user()->tenant_id;
            $validIds = Copropiedad::whereIn('id', $request->input('copropiedad_ids'))
                ->where('tenant_id', $tenantId)
                ->pluck('id')
                ->toArray();

            if (count($validIds) !== count($request->input('copropiedad_ids'))) {
                return response()->json([
                    'success' => false,
                    'message' => 'No tiene acceso a todas las copropiedades solicitadas',
                ], 403);
            }

            $result = $this->precessionService->compareAnalyses($validIds);

            return response()->json([
                'success' => true,
                'data' => $result,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error en comparación',
                'error' => config('app.debug') ? $e->getMessage() : 'Error interno',
            ], 500);
        }
    }

    /**
     * GET /api/v1/pae/alerts
     * Listar alertas activas
     */
    public function alerts(Request $request): JsonResponse
    {
        $query = PrecessionAlert::where('tenant_id', auth()->user()->tenant_id)
            ->where('status', 'active');

        if ($request->has('copropiedad_id')) {
            $query->where('copropiedad_id', $request->input('copropiedad_id'));
        }

        if ($request->has('severity')) {
            $query->where('severity', $request->input('severity'));
        }

        $alerts = $query->orderByDesc('created_at')
            ->paginate($request->input('per_page', 20));

        return response()->json([
            'success' => true,
            'data' => $alerts->items(),
            'meta' => [
                'current_page' => $alerts->currentPage(),
                'last_page' => $alerts->lastPage(),
                'per_page' => $alerts->perPage(),
                'total' => $alerts->total(),
            ],
        ]);
    }

    /**
     * GET /api/v1/pae/alerts/{id}
     * Detalle de alerta
     */
    public function alertDetail(int $alertId): JsonResponse
    {
        $alert = PrecessionAlert::where('id', $alertId)
            ->where('tenant_id', auth()->user()->tenant_id)
            ->with('copropiedad:id,nombre')
            ->firstOrFail();

        return response()->json([
            'success' => true,
            'data' => $alert,
        ]);
    }

    /**
     * PUT /api/v1/pae/alerts/{id}/acknowledge
     * Reconocer alerta
     */
    public function acknowledgeAlert(Request $request, int $alertId): JsonResponse
    {
        $alert = PrecessionAlert::where('id', $alertId)
            ->where('tenant_id', auth()->user()->tenant_id)
            ->where('status', 'active')
            ->firstOrFail();

        $alert->update([
            'status' => 'acknowledged',
            'metadata' => array_merge($alert->metadata ?? [], [
                'acknowledged_by' => auth()->id(),
                'acknowledged_at' => now()->toIso8601String(),
                'notes' => $request->input('notes'),
            ]),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Alerta reconocida',
            'data' => $alert->fresh(),
        ]);
    }

    /**
     * PUT /api/v1/pae/alerts/{id}/resolve
     * Resolver alerta
     */
    public function resolveAlert(Request $request, int $alertId): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'resolution_notes' => 'required|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        $alert = PrecessionAlert::where('id', $alertId)
            ->where('tenant_id', auth()->user()->tenant_id)
            ->whereIn('status', ['active', 'acknowledged'])
            ->firstOrFail();

        $alert->update([
            'status' => 'resolved',
            'resolved_at' => now(),
            'resolved_by' => auth()->id(),
            'resolution_notes' => $request->input('resolution_notes'),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Alerta resuelta',
            'data' => $alert->fresh(),
        ]);
    }

    /**
     * GET /api/v1/pae/dashboard
     * Dashboard general de PAE
     */
    public function dashboard(Request $request): JsonResponse
    {
        $tenantId = auth()->user()->tenant_id;

        // Obtener copropiedades del tenant
        $copropiedadIds = Copropiedad::where('tenant_id', $tenantId)
            ->where('activa', true)
            ->pluck('id');

        // Estadísticas de alertas
        $alertStats = [
            'total_active' => PrecessionAlert::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->count(),
            'critical' => PrecessionAlert::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('severity', 'critical')
                ->count(),
            'high' => PrecessionAlert::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('severity', 'high')
                ->count(),
            'resolved_last_30_days' => PrecessionAlert::where('tenant_id', $tenantId)
                ->where('status', 'resolved')
                ->where('resolved_at', '>=', now()->subDays(30))
                ->count(),
        ];

        // Últimos análisis por copropiedad
        $latestAnalyses = [];
        foreach ($copropiedadIds as $copId) {
            $analysis = PrecessionAnalysis::where('copropiedad_id', $copId)
                ->where('status', 'completed')
                ->latest()
                ->first();
            
            if ($analysis) {
                $latestAnalyses[$copId] = [
                    'id' => $analysis->id,
                    'date' => $analysis->created_at->toIso8601String(),
                    'precession_score' => $analysis->precession_score,
                    'risk_score' => $analysis->risk_score,
                    'value_uf' => $analysis->total_precession_value_uf,
                ];
            }
        }

        // Valor total del portafolio
        $totalValue = PrecessionAnalysis::whereIn('copropiedad_id', $copropiedadIds)
            ->where('status', 'completed')
            ->whereIn('id', function ($query) use ($copropiedadIds) {
                $query->selectRaw('MAX(id)')
                    ->from('precession_analyses')
                    ->whereIn('copropiedad_id', $copropiedadIds)
                    ->groupBy('copropiedad_id');
            })
            ->sum('total_precession_value_uf');

        // Promedios
        $avgScores = PrecessionAnalysis::whereIn('copropiedad_id', $copropiedadIds)
            ->where('status', 'completed')
            ->whereIn('id', function ($query) use ($copropiedadIds) {
                $query->selectRaw('MAX(id)')
                    ->from('precession_analyses')
                    ->whereIn('copropiedad_id', $copropiedadIds)
                    ->groupBy('copropiedad_id');
            })
            ->selectRaw('AVG(precession_score) as avg_precession, AVG(risk_score) as avg_risk, AVG(opportunity_score) as avg_opportunity')
            ->first();

        return response()->json([
            'success' => true,
            'data' => [
                'copropiedades_count' => $copropiedadIds->count(),
                'alerts' => $alertStats,
                'portfolio_value_uf' => round($totalValue, 2),
                'average_scores' => [
                    'precession' => round($avgScores->avg_precession ?? 0, 2),
                    'risk' => round($avgScores->avg_risk ?? 0, 2),
                    'opportunity' => round($avgScores->avg_opportunity ?? 0, 2),
                ],
                'analyses_by_copropiedad' => $latestAnalyses,
                'generated_at' => now()->toIso8601String(),
            ],
        ]);
    }

    /**
     * DELETE /api/v1/copropiedades/{id}/pae/cache
     * Invalidar cache de análisis
     */
    public function invalidateCache(int $copropiedadId): JsonResponse
    {
        $this->precessionService->invalidateCache($copropiedadId);

        return response()->json([
            'success' => true,
            'message' => 'Cache invalidado',
        ]);
    }

    /**
     * Obtener análisis cacheado
     */
    protected function getCachedAnalysis(int $copropiedadId): ?array
    {
        $analysis = PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
            ->where('status', 'completed')
            ->where('expires_at', '>', now())
            ->latest()
            ->first();

        if (!$analysis) {
            return null;
        }

        return $this->formatAnalysisResponse($analysis);
    }

    /**
     * Formatear respuesta de análisis
     */
    protected function formatAnalysisResponse(PrecessionAnalysis $analysis): array
    {
        return [
            'id' => $analysis->id,
            'copropiedad_id' => $analysis->copropiedad_id,
            'analysis_type' => $analysis->analysis_type,
            'status' => $analysis->status,
            'parameters' => $analysis->parameters,
            'scores' => [
                'precession' => $analysis->precession_score,
                'risk' => $analysis->risk_score,
                'opportunity' => $analysis->opportunity_score,
                'confidence' => $analysis->confidence,
            ],
            'valuation' => [
                'total_uf' => $analysis->total_precession_value_uf,
                'direct_uf' => $analysis->direct_value_uf,
                'induced_uf' => $analysis->induced_value_uf,
                'precession_uf' => $analysis->precession_value_uf,
                'systemic_uf' => $analysis->systemic_value_uf,
                'counter_uf' => $analysis->counter_value_uf,
            ],
            'effects' => [
                'count' => $analysis->effects_count,
                'summary' => $analysis->effects_summary,
            ],
            'alerts' => $analysis->alerts->map(fn($a) => [
                'id' => $a->id,
                'type' => $a->alert_type,
                'severity' => $a->severity,
                'title' => $a->title,
                'status' => $a->status,
            ]),
            'performance' => [
                'execution_time_ms' => $analysis->execution_time_ms,
                'expires_at' => $analysis->expires_at?->toIso8601String(),
            ],
            'created_at' => $analysis->created_at->toIso8601String(),
            'synced_to_agora' => $analysis->synced_to_agora,
        ];
    }
}
