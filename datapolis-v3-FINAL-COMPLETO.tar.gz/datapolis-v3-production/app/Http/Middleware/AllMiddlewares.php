<?php
/**
 * DATAPOLIS v3.0 - Middlewares
 */

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

// =============================================================================
// TenantScope - Aislamiento Multi-Tenant
// =============================================================================
class TenantScope
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check()) {
            $tenantId = auth()->user()->tenant_id;
            
            // Set global scope for all queries
            config(['database.connections.mysql.tenant_id' => $tenantId]);
            
            // Add tenant_id to request for controllers
            $request->merge(['tenant_id' => $tenantId]);
        }

        return $next($request);
    }
}

// =============================================================================
// CheckRole - Verificar Rol del Usuario
// =============================================================================
class CheckRole
{
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        if (!auth()->check()) {
            return response()->json(['message' => 'Unauthenticated'], 401);
        }

        foreach ($roles as $role) {
            if (auth()->user()->hasRole($role)) {
                return $next($request);
            }
        }

        return response()->json(['message' => 'Forbidden - Role required: ' . implode(' or ', $roles)], 403);
    }
}

// =============================================================================
// CheckPermission - Verificar Permiso del Usuario
// =============================================================================
class CheckPermission
{
    public function handle(Request $request, Closure $next, ...$permissions): Response
    {
        if (!auth()->check()) {
            return response()->json(['message' => 'Unauthenticated'], 401);
        }

        foreach ($permissions as $permission) {
            if (auth()->user()->hasPermissionTo($permission)) {
                return $next($request);
            }
        }

        return response()->json(['message' => 'Forbidden - Permission required: ' . implode(' or ', $permissions)], 403);
    }
}

// =============================================================================
// EnsureEmailIsVerified
// =============================================================================
class EnsureEmailIsVerified
{
    public function handle(Request $request, Closure $next, ?string $redirectToRoute = null): Response
    {
        if (!$request->user() || !$request->user()->hasVerifiedEmail()) {
            return response()->json(['message' => 'Your email address is not verified.'], 409);
        }

        return $next($request);
    }
}

// =============================================================================
// AuditLog - Registro de Auditoría
// =============================================================================
class AuditLog
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        // Log solo para métodos que modifican datos
        if (in_array($request->method(), ['POST', 'PUT', 'PATCH', 'DELETE'])) {
            \App\Models\AuditLog::create([
                'tenant_id' => auth()->user()?->tenant_id,
                'user_id' => auth()->id(),
                'action' => $request->method(),
                'model_type' => null,
                'model_id' => null,
                'description' => $request->path(),
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
                'old_values' => null,
                'new_values' => $request->except(['password', 'password_confirmation']),
            ]);
        }

        return $response;
    }
}

// =============================================================================
// ForceHttps - Forzar HTTPS en producción
// =============================================================================
class ForceHttps
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!$request->secure() && app()->environment('production')) {
            return redirect()->secure($request->getRequestUri());
        }

        return $next($request);
    }
}

// =============================================================================
// JsonResponse - Forzar respuestas JSON
// =============================================================================
class JsonResponse
{
    public function handle(Request $request, Closure $next): Response
    {
        $request->headers->set('Accept', 'application/json');
        
        return $next($request);
    }
}
