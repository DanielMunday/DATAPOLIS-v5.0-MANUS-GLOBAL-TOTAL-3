<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TenantScope
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check()) {
            $tenantId = auth()->user()->tenant_id;
            config(['database.connections.mysql.tenant_id' => $tenantId]);
            $request->merge(['tenant_id' => $tenantId]);
        }

        return $next($request);
    }
}
