<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Copropiedad extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'copropiedades';

    protected $fillable = [
        'uuid', 'tenant_id', 'nombre', 'rut', 'direccion', 'numero', 'comuna', 'region',
        'codigo_postal', 'latitud', 'longitud', 'tipo', 'ano_construccion', 'total_unidades',
        'total_pisos', 'superficie_terreno', 'superficie_construida', 'tiene_administrador',
        'tiene_conserje', 'tiene_inicio_actividades', 'regimen_tributario', 'sii_giro',
        'representante_legal', 'rut_representante', 'email', 'telefono', 'configuracion', 'activa'
    ];

    protected $casts = [
        'configuracion' => 'array',
        'activa' => 'boolean',
        'tiene_administrador' => 'boolean',
        'tiene_conserje' => 'boolean',
        'tiene_inicio_actividades' => 'boolean',
        'latitud' => 'decimal:8',
        'longitud' => 'decimal:8',
    ];

    public function tenant() { return $this->belongsTo(Tenant::class); }
    public function unidades() { return $this->hasMany(Unidad::class); }
    public function contratosAntenas() { return $this->hasMany(ContratoAntena::class); }
    public function periodosGasto() { return $this->hasMany(PeriodoGasto::class); }
    public function fondoReserva() { return $this->hasOne(FondoReserva::class); }
    public function asambleas() { return $this->hasMany(Asamblea::class); }
    public function proveedores() { return $this->belongsToMany(Proveedor::class); }
    public function periodosContables() { return $this->hasMany(PeriodoContable::class); }
    public function comunicados() { return $this->hasMany(Comunicado::class); }
    public function espaciosComunes() { return $this->hasMany(EspacioComun::class); }
    
    public function scopeActivas($query) { return $query->where('activa', true); }
}
