<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PeriodoGasto extends Model
{
    protected $table = 'periodos_gasto';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'periodo', 'ano', 'mes', 'fecha_inicio',
        'fecha_cierre', 'fecha_vencimiento', 'total_gastos_ordinarios', 'total_gastos_extraordinarios',
        'fondo_reserva_aporte', 'estado', 'cerrado_por', 'fecha_cierre_real'
    ];
    protected $casts = ['fecha_inicio' => 'date', 'fecha_cierre' => 'date', 'fecha_vencimiento' => 'date'];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function gastos() { return $this->hasMany(GastoComun::class, 'periodo_id'); }
    public function cobros() { return $this->hasMany(CobroUnidad::class, 'periodo_id'); }
}
