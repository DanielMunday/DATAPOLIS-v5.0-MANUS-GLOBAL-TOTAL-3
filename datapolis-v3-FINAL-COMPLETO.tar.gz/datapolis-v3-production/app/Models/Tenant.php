<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Tenant extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'uuid', 'name', 'slug', 'rut', 'razon_social', 'giro', 'direccion',
        'comuna', 'region', 'telefono', 'email', 'website', 'logo', 'plan',
        'settings', 'features', 'active', 'trial_ends_at', 'subscription_ends_at'
    ];

    protected $casts = [
        'settings' => 'array',
        'features' => 'array',
        'active' => 'boolean',
        'trial_ends_at' => 'datetime',
        'subscription_ends_at' => 'datetime',
    ];

    public function users(): HasMany { return $this->hasMany(User::class); }
    public function copropiedades(): HasMany { return $this->hasMany(Copropiedad::class); }
}
