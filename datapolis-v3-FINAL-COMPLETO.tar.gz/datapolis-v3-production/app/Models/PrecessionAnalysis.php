<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class PrecessionAnalysis extends Model
{
    use HasUuids;
    protected $table = 'precession_analyses';
    protected $keyType = 'string';
    public $incrementing = false;
    
    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'analysis_type', 'status', 'parameters',
        'precession_score', 'risk_score', 'opportunity_score', 'confidence',
        'total_precession_value_uf', 'direct_value_uf', 'induced_value_uf',
        'precession_value_uf', 'systemic_value_uf', 'counter_value_uf',
        'effects_summary', 'effects_count', 'execution_time_ms', 'expires_at', 'synced_to_agora'
    ];
    protected $casts = [
        'parameters' => 'array', 'effects_summary' => 'array',
        'expires_at' => 'datetime', 'synced_to_agora' => 'boolean'
    ];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function alerts() { return $this->hasMany(PrecessionAlert::class); }
}
