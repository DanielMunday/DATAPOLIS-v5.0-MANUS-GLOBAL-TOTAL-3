<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class FondoReserva extends Model
{
    protected $table = 'fondos_reserva';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'saldo_actual', 'saldo_minimo_legal',
        'porcentaje_aporte_mensual', 'cuenta_bancaria', 'banco', 'tipo_cuenta'
    ];
    protected $casts = ['saldo_actual' => 'decimal:2', 'porcentaje_aporte_mensual' => 'decimal:2'];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function movimientos() { return $this->hasMany(MovimientoFondoReserva::class, 'fondo_id'); }
}
