<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CertificadoTributario extends Model
{
    protected $table = 'certificados_tributarios';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'copropietario_id', 'unidad_id',
        'tipo', 'ano_tributario', 'folio', 'fecha_emision', 'fecha_vigencia',
        'monto_ingresos', 'monto_gastos', 'monto_participacion', 'porcentaje_participacion',
        'detalle', 'estado', 'codigo_verificacion', 'emitido_por'
    ];
    protected $casts = ['fecha_emision' => 'date', 'fecha_vigencia' => 'date', 'detalle' => 'array'];
    
    public static function generarFolio($tenantId, $ano) {
        $ultimo = static::where('tenant_id', $tenantId)->where('ano_tributario', $ano)->max('folio') ?? 0;
        return $ultimo + 1;
    }
}
