<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class MovimientoContable extends Model
{
    protected $table = 'movimientos_contables';
    protected $fillable = [
        'tenant_id', 'asiento_id', 'cuenta_id', 'tipo_movimiento', 'monto', 'glosa_linea'
    ];
    public function asiento() { return $this->belongsTo(AsientoContable::class); }
    public function cuenta() { return $this->belongsTo(PlanCuenta::class, 'cuenta_id'); }
}
