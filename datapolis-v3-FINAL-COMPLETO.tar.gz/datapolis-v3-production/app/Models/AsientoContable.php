<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class AsientoContable extends Model
{
    protected $table = 'asientos_contables';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'periodo_contable_id', 'numero_asiento',
        'fecha', 'tipo', 'glosa', 'documento_tipo', 'documento_id', 'total_debe',
        'total_haber', 'estado', 'creado_por', 'aprobado_por', 'fecha_aprobacion'
    ];
    protected $casts = ['fecha' => 'date', 'fecha_aprobacion' => 'datetime'];
    public function periodo() { return $this->belongsTo(PeriodoContable::class, 'periodo_contable_id'); }
    public function movimientos() { return $this->hasMany(MovimientoContable::class, 'asiento_id'); }
}
