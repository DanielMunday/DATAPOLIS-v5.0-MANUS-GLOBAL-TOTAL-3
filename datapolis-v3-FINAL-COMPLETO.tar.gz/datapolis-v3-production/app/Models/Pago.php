<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Pago extends Model
{
    protected $table = 'pagos';
    protected $fillable = [
        'uuid', 'tenant_id', 'cobro_unidad_id', 'fecha_pago', 'monto', 'medio_pago',
        'numero_operacion', 'banco', 'comprobante', 'registrado_por', 'observaciones'
    ];
    protected $casts = ['fecha_pago' => 'date'];
    public function cobroUnidad() { return $this->belongsTo(CobroUnidad::class); }
}
