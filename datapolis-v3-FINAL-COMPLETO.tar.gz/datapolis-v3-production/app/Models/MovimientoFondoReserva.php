<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class MovimientoFondoReserva extends Model
{
    protected $table = 'movimientos_fondo_reserva';
    protected $fillable = [
        'tenant_id', 'fondo_id', 'fecha', 'tipo', 'monto', 'saldo_posterior',
        'descripcion', 'documento_respaldo', 'periodo', 'aprobado_por'
    ];
    protected $casts = ['fecha' => 'date'];
    public function fondo() { return $this->belongsTo(FondoReserva::class); }
}
