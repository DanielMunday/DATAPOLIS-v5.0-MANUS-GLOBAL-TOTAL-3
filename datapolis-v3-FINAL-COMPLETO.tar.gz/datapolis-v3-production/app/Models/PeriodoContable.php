<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PeriodoContable extends Model
{
    protected $table = 'periodos_contables';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'ano', 'mes', 'fecha_inicio',
        'fecha_cierre', 'estado', 'cerrado_por', 'fecha_cierre_real'
    ];
    protected $casts = ['fecha_inicio' => 'date', 'fecha_cierre' => 'date'];
    public function asientos() { return $this->hasMany(AsientoContable::class); }
    public function saldos() { return $this->hasMany(SaldoCuenta::class); }
}
