<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class SaldoCuenta extends Model
{
    protected $table = 'saldos_cuentas';
    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'cuenta_id', 'periodo_contable_id',
        'saldo_inicial', 'debitos', 'creditos', 'saldo_final'
    ];
    public function cuenta() { return $this->belongsTo(PlanCuenta::class); }
    public function periodo() { return $this->belongsTo(PeriodoContable::class, 'periodo_contable_id'); }
}
