<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class UfHistorico extends Model
{
    protected $table = 'uf_historico';
    protected $fillable = ['fecha', 'valor'];
    protected $casts = ['fecha' => 'date', 'valor' => 'decimal:4'];
    
    public static function getValor($fecha = null)
    {
        $fecha = $fecha ?? now()->toDateString();
        return Cache::remember("uf_{$fecha}", 3600, function() use ($fecha) {
            return static::where('fecha', '<=', $fecha)->orderByDesc('fecha')->value('valor') ?? 38000;
        });
    }
}
