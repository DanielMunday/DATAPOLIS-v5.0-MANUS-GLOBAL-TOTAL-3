<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class FacturaAntena extends Model
{
    protected $table = 'facturas_antena';
    protected $fillable = [
        'uuid', 'tenant_id', 'contrato_antena_id', 'copropiedad_id', 'fecha_emision',
        'fecha_vencimiento', 'periodo', 'monto_neto_uf', 'monto_neto_clp', 'monto_iva',
        'monto_total_clp', 'valor_uf_dia', 'iva_incluido', 'tasa_iva_aplicada',
        'folio_dte', 'track_id_sii', 'estado', 'fecha_pago', 'observaciones'
    ];
    protected $casts = ['fecha_emision' => 'date', 'fecha_vencimiento' => 'date', 'fecha_pago' => 'date'];
    public function contrato() { return $this->belongsTo(ContratoAntena::class, 'contrato_antena_id'); }
    public function distribuciones() { return $this->hasMany(DistribucionIngresoAntena::class); }
}
