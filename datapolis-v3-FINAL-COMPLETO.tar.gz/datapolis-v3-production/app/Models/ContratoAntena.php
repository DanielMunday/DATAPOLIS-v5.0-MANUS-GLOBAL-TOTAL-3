<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContratoAntena extends Model
{
    use SoftDeletes;
    protected $table = 'contratos_antena';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'espacio_comun_id', 'numero_contrato',
        'empresa_operador', 'rut_operador', 'tipo_antena', 'fecha_inicio', 'fecha_termino',
        'canon_mensual_uf', 'reajuste_anual', 'afecto_iva', 'tasa_iva', 'porcentaje_fondo_comun',
        'porcentaje_fondo_reserva', 'porcentaje_propietarios', 'renovacion_automatica',
        'meses_aviso_termino', 'acta_asamblea_numero', 'acta_asamblea_fecha', 'estado', 'observaciones'
    ];
    protected $casts = [
        'fecha_inicio' => 'date', 'fecha_termino' => 'date', 'acta_asamblea_fecha' => 'date',
        'canon_mensual_uf' => 'decimal:4', 'afecto_iva' => 'boolean', 'renovacion_automatica' => 'boolean'
    ];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function facturas() { return $this->hasMany(FacturaAntena::class); }
    public function scopeVigentes($q) { return $q->where('estado', 'vigente'); }
}
