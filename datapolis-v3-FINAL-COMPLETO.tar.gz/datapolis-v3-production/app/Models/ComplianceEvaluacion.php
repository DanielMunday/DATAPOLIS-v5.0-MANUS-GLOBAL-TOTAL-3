<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ComplianceEvaluacion extends Model
{
    protected $table = 'compliance_evaluaciones';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'fecha_evaluacion', 'periodo_evaluado',
        'score_global', 'score_ley21442', 'score_ds7_2025', 'score_tributario',
        'score_contable', 'score_transparencia', 'brechas', 'recomendaciones',
        'plan_accion', 'estado', 'evaluador_id'
    ];
    protected $casts = [
        'fecha_evaluacion' => 'datetime',
        'brechas' => 'array',
        'recomendaciones' => 'array',
        'plan_accion' => 'array'
    ];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
}
