<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Asamblea extends Model
{
    protected $table = 'asambleas';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'tipo', 'numero', 'fecha', 'hora_inicio',
        'hora_termino', 'lugar', 'convocatoria_fecha', 'quorum_requerido', 'quorum_asistente',
        'tabla', 'acta', 'estado', 'acta_firmada', 'fecha_publicacion_acta'
    ];
    protected $casts = ['fecha' => 'date', 'convocatoria_fecha' => 'date', 'tabla' => 'array'];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
}
