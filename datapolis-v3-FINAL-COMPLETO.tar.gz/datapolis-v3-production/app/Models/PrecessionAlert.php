<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class PrecessionAlert extends Model
{
    use HasUuids;
    protected $table = 'precession_alerts';
    protected $keyType = 'string';
    public $incrementing = false;
    
    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'precession_analysis_id', 'alert_type',
        'severity', 'title', 'description', 'probability', 'potential_impact_uf',
        'expected_months', 'recommended_actions', 'status', 'resolved_at',
        'resolved_by', 'resolution_notes', 'metadata', 'synced_to_agora'
    ];
    protected $casts = [
        'recommended_actions' => 'array', 'metadata' => 'array',
        'resolved_at' => 'datetime', 'synced_to_agora' => 'boolean'
    ];
}
