<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CategoriaGasto extends Model
{
    protected $table = 'categorias_gasto';
    protected $fillable = ['tenant_id', 'nombre', 'codigo', 'tipo', 'descripcion', 'cuenta_contable', 'activa'];
    protected $casts = ['activa' => 'boolean'];
    public function gastos() { return $this->hasMany(GastoComun::class, 'categoria_id'); }
}
