<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CobroUnidad extends Model
{
    protected $table = 'cobros_unidad';
    protected $fillable = [
        'uuid', 'tenant_id', 'unidad_id', 'periodo_id', 'gasto_ordinario', 'gasto_extraordinario',
        'fondo_reserva', 'intereses_mora', 'otros_cargos', 'descuentos', 'total_cobrar',
        'total_pagado', 'saldo_pendiente', 'fecha_vencimiento', 'estado'
    ];
    protected $casts = ['fecha_vencimiento' => 'date'];
    public function unidad() { return $this->belongsTo(Unidad::class); }
    public function periodo() { return $this->belongsTo(PeriodoGasto::class); }
    public function pagos() { return $this->hasMany(Pago::class, 'cobro_unidad_id'); }
}
