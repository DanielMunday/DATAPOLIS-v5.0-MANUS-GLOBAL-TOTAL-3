<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Proveedor extends Model
{
    use SoftDeletes;
    protected $table = 'proveedores';
    protected $fillable = [
        'uuid', 'tenant_id', 'rut', 'razon_social', 'nombre_fantasia', 'giro',
        'direccion', 'comuna', 'telefono', 'email', 'contacto_nombre', 'contacto_telefono',
        'cuenta_bancaria', 'banco', 'tipo_cuenta', 'activo'
    ];
    protected $casts = ['activo' => 'boolean'];
}
