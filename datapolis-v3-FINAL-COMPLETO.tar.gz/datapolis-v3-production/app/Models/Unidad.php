<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Unidad extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'unidades';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'numero', 'piso', 'tipo', 'rol_sii',
        'superficie_util', 'superficie_terraza', 'superficie_total', 'habitaciones',
        'banos', 'estacionamientos', 'bodegas', 'alicuota_prorrateo', 'estado', 'activa'
    ];

    protected $casts = [
        'alicuota_prorrateo' => 'decimal:6',
        'activa' => 'boolean',
    ];

    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function copropietarios() { return $this->hasMany(Copropietario::class); }
    public function cobros() { return $this->hasMany(CobroUnidad::class); }
    public function morosidad() { return $this->hasOne(Morosidad::class); }
    
    public function scopeActivas($query) { return $query->where('activa', true); }
    
    public function getPropietarioPrincipal()
    {
        return $this->copropietarios()->where('es_principal', true)->first();
    }
}
