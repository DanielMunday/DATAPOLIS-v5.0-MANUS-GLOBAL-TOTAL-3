<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Comunicado extends Model
{
    protected $table = 'comunicados';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'titulo', 'contenido', 'tipo',
        'fecha_publicacion', 'fecha_expiracion', 'importante', 'publicado_por', 'estado'
    ];
    protected $casts = ['fecha_publicacion' => 'datetime', 'fecha_expiracion' => 'datetime', 'importante' => 'boolean'];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
}
