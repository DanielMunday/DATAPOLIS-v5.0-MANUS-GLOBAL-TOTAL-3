<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PlanCuenta extends Model
{
    protected $table = 'plan_cuentas';
    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'codigo', 'nombre', 'tipo', 'naturaleza',
        'nivel', 'padre_id', 'es_movimiento', 'activa'
    ];
    protected $casts = ['es_movimiento' => 'boolean', 'activa' => 'boolean'];
    public function padre() { return $this->belongsTo(PlanCuenta::class, 'padre_id'); }
    public function hijos() { return $this->hasMany(PlanCuenta::class, 'padre_id'); }
}
