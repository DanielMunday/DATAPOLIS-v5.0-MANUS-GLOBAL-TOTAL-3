<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class EspacioComun extends Model
{
    protected $table = 'espacios_comunes';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'nombre', 'tipo', 'ubicacion',
        'superficie', 'capacidad', 'tiene_contrato_antena', 'activo'
    ];
    protected $casts = ['tiene_contrato_antena' => 'boolean', 'activo' => 'boolean'];
    public function copropiedad() { return $this->belongsTo(Copropiedad::class); }
    public function contratosAntenas() { return $this->hasMany(ContratoAntena::class); }
}
