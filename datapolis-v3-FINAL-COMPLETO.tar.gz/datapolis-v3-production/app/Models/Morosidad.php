<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Morosidad extends Model
{
    protected $table = 'morosidades';
    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'unidad_id', 'deuda_total', 'meses_mora',
        'periodo_mas_antiguo', 'fecha_inicio_mora', 'categoria_riesgo', 'en_cobranza_judicial',
        'fecha_ultima_gestion', 'observaciones'
    ];
    protected $casts = ['fecha_inicio_mora' => 'date', 'en_cobranza_judicial' => 'boolean'];
    public function unidad() { return $this->belongsTo(Unidad::class); }
}
