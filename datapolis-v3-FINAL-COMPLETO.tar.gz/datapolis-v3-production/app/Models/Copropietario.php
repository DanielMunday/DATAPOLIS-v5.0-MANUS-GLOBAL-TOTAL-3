<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Copropietario extends Model
{
    use SoftDeletes;
    protected $table = 'copropietarios';
    protected $fillable = [
        'uuid', 'tenant_id', 'unidad_id', 'tipo_persona', 'rut', 'nombre', 'apellido_paterno',
        'apellido_materno', 'razon_social', 'email', 'telefono', 'direccion_correspondencia',
        'es_propietario', 'es_arrendatario', 'es_residente', 'es_principal', 'fecha_inicio', 'fecha_termino'
    ];
    protected $casts = ['es_propietario' => 'boolean', 'es_arrendatario' => 'boolean', 'es_residente' => 'boolean', 'es_principal' => 'boolean'];
    public function unidad() { return $this->belongsTo(Unidad::class); }
    public function getNombreCompleto() {
        return $this->tipo_persona === 'natural' 
            ? trim("{$this->nombre} {$this->apellido_paterno} {$this->apellido_materno}")
            : $this->razon_social;
    }
}
