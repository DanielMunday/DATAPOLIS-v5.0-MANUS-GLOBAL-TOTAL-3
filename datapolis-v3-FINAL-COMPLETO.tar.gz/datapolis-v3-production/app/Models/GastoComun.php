<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class GastoComun extends Model
{
    protected $table = 'gastos_comunes';
    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'periodo_id', 'categoria_id', 'proveedor_id',
        'fecha', 'descripcion', 'monto_neto', 'monto_iva', 'monto_total', 'tipo_documento',
        'numero_documento', 'prorrateable', 'estado', 'aprobado_por', 'fecha_aprobacion'
    ];
    protected $casts = ['fecha' => 'date', 'prorrateable' => 'boolean'];
    public function periodo() { return $this->belongsTo(PeriodoGasto::class); }
    public function categoria() { return $this->belongsTo(CategoriaGasto::class); }
}
