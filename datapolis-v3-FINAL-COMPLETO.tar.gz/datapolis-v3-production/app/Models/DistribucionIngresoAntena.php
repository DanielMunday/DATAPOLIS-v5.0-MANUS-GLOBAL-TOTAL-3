<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class DistribucionIngresoAntena extends Model
{
    protected $table = 'distribuciones_ingreso_antena';
    protected $fillable = [
        'tenant_id', 'factura_antena_id', 'unidad_id', 'copropietario_id', 'tipo_destino',
        'porcentaje', 'monto_bruto_clp', 'monto_neto_clp', 'monto_uf'
    ];
    public function facturaAntena() { return $this->belongsTo(FacturaAntena::class); }
}
