<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRoles;

    protected $fillable = [
        'uuid', 'tenant_id', 'name', 'email', 'password', 'rut', 'telefono',
        'cargo', 'avatar', 'settings', 'activo', 'last_login_at', 'email_verified_at'
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'password' => 'hashed',
        'settings' => 'array',
        'activo' => 'boolean',
    ];

    public function tenant() { return $this->belongsTo(Tenant::class); }
    public function copropiedades() { return $this->belongsToMany(Copropiedad::class, 'copropiedad_user'); }
}
