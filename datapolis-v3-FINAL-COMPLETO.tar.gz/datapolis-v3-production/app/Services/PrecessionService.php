<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - PAE M11 - PRECESSION SERVICE
 * Motor de Análisis Precesional para Copropiedades
 * =========================================================================
 * 
 * Implementa el concepto de "precesión económica" aplicado a copropiedades:
 * - Efectos directos: Impactos inmediatos de decisiones
 * - Efectos inducidos: Consecuencias de segundo orden
 * - Efectos precesionales: Impactos laterales no anticipados
 * - Efectos sistémicos: Cambios en el ecosistema completo
 * - Contra-efectos: Reacciones negativas o resistencias
 */

namespace App\Services;

use App\Models\{
    Copropiedad, Unidad, ContratoAntena, FacturaAntena,
    PeriodoGasto, GastoComun, CobroUnidad, Morosidad,
    FondoReserva, ComplianceEvaluacion, PrecessionAnalysis, 
    PrecessionAlert, UfHistorico
};
use App\Services\PAE\{
    PrecessionGraphEngine,
    PrecessionScoringEngine,
    PrecessionAlertEngine,
    PrecessionSyncService
};
use Illuminate\Support\Facades\{DB, Cache, Log};
use Carbon\Carbon;

class PrecessionService
{
    protected PrecessionGraphEngine $graphEngine;
    protected PrecessionScoringEngine $scoringEngine;
    protected PrecessionAlertEngine $alertEngine;
    protected PrecessionSyncService $syncService;

    public function __construct()
    {
        $this->graphEngine = app(PrecessionGraphEngine::class);
        $this->scoringEngine = app(PrecessionScoringEngine::class);
        $this->alertEngine = app(PrecessionAlertEngine::class);
        $this->syncService = app(PrecessionSyncService::class);
    }

    /**
     * Ejecutar análisis precesional completo para una copropiedad
     */
    public function analyzeCopropiedad(int $copropiedadId, array $params = []): PrecessionAnalysis
    {
        $startTime = microtime(true);
        
        $copropiedad = Copropiedad::with([
            'unidades.morosidad',
            'contratosAntenas.facturas',
            'fondoReserva.movimientos',
            'periodosGasto.gastos',
            'asambleas'
        ])->findOrFail($copropiedadId);

        $horizon = $params['horizon'] ?? config('datapolis.pae.default_horizon', 36);
        $depth = $params['depth'] ?? config('datapolis.pae.default_depth', 4);

        // 1. Construir grafo ontológico
        $graph = $this->graphEngine->buildGraph($copropiedad);

        // 2. Calcular efectos de precesión
        $effects = $this->graphEngine->calculatePrecessionEffects($graph, $depth);

        // 3. Calcular scores
        $scores = $this->scoringEngine->calculateScores($effects, $copropiedad);

        // 4. Calcular valoración
        $valuation = $this->scoringEngine->calculateValuation($copropiedad, $effects);

        // 5. Crear registro de análisis
        $analysis = PrecessionAnalysis::create([
            'tenant_id' => $copropiedad->tenant_id,
            'copropiedad_id' => $copropiedadId,
            'analysis_type' => $params['type'] ?? 'full',
            'status' => 'completed',
            'parameters' => [
                'horizon' => $horizon,
                'depth' => $depth,
                'requested_at' => now()->toIso8601String(),
            ],
            'precession_score' => $scores['precession_score'],
            'risk_score' => $scores['risk_score'],
            'opportunity_score' => $scores['opportunity_score'],
            'confidence' => $scores['confidence'],
            'total_precession_value_uf' => $valuation['total'],
            'direct_value_uf' => $valuation['direct'],
            'induced_value_uf' => $valuation['induced'],
            'precession_value_uf' => $valuation['precession'],
            'systemic_value_uf' => $valuation['systemic'],
            'counter_value_uf' => $valuation['counter'],
            'effects_summary' => $this->summarizeEffects($effects),
            'effects_count' => count($effects),
            'execution_time_ms' => (microtime(true) - $startTime) * 1000,
            'expires_at' => now()->addMinutes(config('datapolis.pae.cache_ttl', 30)),
            'synced_to_agora' => false,
        ]);

        // 6. Generar alertas
        $this->generateAlerts($analysis, $copropiedad, $effects, $scores);

        // 7. Sincronizar con ÁGORA (async)
        if (config('datapolis.pae.enabled')) {
            dispatch(function () use ($analysis) {
                $this->syncService->syncAnalysis($analysis);
            })->afterResponse();
        }

        return $analysis->load('alerts');
    }

    /**
     * Análisis rápido (cached)
     */
    public function quickAnalysis(int $copropiedadId): array
    {
        $cacheKey = "pae_quick_{$copropiedadId}";
        $cacheTtl = config('datapolis.pae.cache_ttl', 1800);

        return Cache::remember($cacheKey, $cacheTtl, function () use ($copropiedadId) {
            $analysis = $this->analyzeCopropiedad($copropiedadId, ['type' => 'quick']);
            
            return [
                'analysis_id' => $analysis->id,
                'scores' => [
                    'precession' => $analysis->precession_score,
                    'risk' => $analysis->risk_score,
                    'opportunity' => $analysis->opportunity_score,
                ],
                'valuation_uf' => $analysis->total_precession_value_uf,
                'alerts_count' => $analysis->alerts->count(),
                'critical_alerts' => $analysis->alerts->where('severity', 'critical')->count(),
                'computed_at' => $analysis->created_at->toIso8601String(),
            ];
        });
    }

    /**
     * Análisis comparativo entre copropiedades
     */
    public function compareAnalyses(array $copropiedadIds): array
    {
        $analyses = [];
        
        foreach ($copropiedadIds as $id) {
            $latest = PrecessionAnalysis::where('copropiedad_id', $id)
                ->where('status', 'completed')
                ->latest()
                ->first();
                
            if (!$latest || $latest->expires_at < now()) {
                $latest = $this->analyzeCopropiedad($id);
            }
            
            $analyses[$id] = $latest;
        }

        return [
            'analyses' => $analyses,
            'comparison' => $this->buildComparison($analyses),
            'benchmark' => $this->calculateBenchmark($analyses),
        ];
    }

    /**
     * Proyección temporal de efectos
     */
    public function projectEffects(int $copropiedadId, int $months = 12): array
    {
        $analysis = PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
            ->where('status', 'completed')
            ->latest()
            ->firstOrFail();

        $copropiedad = Copropiedad::with('contratosAntenas', 'unidades.morosidad')->find($copropiedadId);
        
        $projections = [];
        $currentDate = now();

        for ($i = 1; $i <= $months; $i++) {
            $projectionDate = $currentDate->copy()->addMonths($i);
            
            $projections[] = [
                'month' => $i,
                'date' => $projectionDate->format('Y-m'),
                'projected_value_uf' => $this->projectValueAtMonth($analysis, $copropiedad, $i),
                'risk_trend' => $this->projectRiskTrend($analysis, $copropiedad, $i),
                'events' => $this->getProjectedEvents($copropiedad, $projectionDate),
            ];
        }

        return [
            'base_analysis' => $analysis->id,
            'projection_months' => $months,
            'projections' => $projections,
            'summary' => [
                'total_projected_value_uf' => array_sum(array_column($projections, 'projected_value_uf')),
                'average_risk' => array_sum(array_column($projections, 'risk_trend')) / $months,
                'key_events' => $this->summarizeKeyEvents($projections),
            ],
        ];
    }

    /**
     * Simulación de escenarios "what-if"
     */
    public function simulateScenario(int $copropiedadId, array $scenario): array
    {
        $copropiedad = Copropiedad::with([
            'unidades.morosidad',
            'contratosAntenas',
            'fondoReserva'
        ])->findOrFail($copropiedadId);

        // Aplicar cambios del escenario temporalmente
        $modifiedCopropiedad = $this->applyScenarioChanges($copropiedad, $scenario);

        // Recalcular con los cambios
        $graph = $this->graphEngine->buildGraph($modifiedCopropiedad);
        $effects = $this->graphEngine->calculatePrecessionEffects($graph, 4);
        $scores = $this->scoringEngine->calculateScores($effects, $modifiedCopropiedad);
        $valuation = $this->scoringEngine->calculateValuation($modifiedCopropiedad, $effects);

        // Obtener análisis actual para comparar
        $currentAnalysis = PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
            ->where('status', 'completed')
            ->latest()
            ->first();

        return [
            'scenario' => $scenario,
            'current' => [
                'precession_score' => $currentAnalysis?->precession_score ?? 0,
                'risk_score' => $currentAnalysis?->risk_score ?? 0,
                'value_uf' => $currentAnalysis?->total_precession_value_uf ?? 0,
            ],
            'simulated' => [
                'precession_score' => $scores['precession_score'],
                'risk_score' => $scores['risk_score'],
                'value_uf' => $valuation['total'],
            ],
            'delta' => [
                'precession_score' => $scores['precession_score'] - ($currentAnalysis?->precession_score ?? 0),
                'risk_score' => $scores['risk_score'] - ($currentAnalysis?->risk_score ?? 0),
                'value_uf' => $valuation['total'] - ($currentAnalysis?->total_precession_value_uf ?? 0),
            ],
            'recommendation' => $this->generateScenarioRecommendation($scenario, $scores, $valuation),
        ];
    }

    /**
     * Generar alertas basadas en el análisis
     */
    protected function generateAlerts(
        PrecessionAnalysis $analysis, 
        Copropiedad $copropiedad, 
        array $effects, 
        array $scores
    ): void {
        $alerts = $this->alertEngine->generateAlerts($copropiedad, $effects, $scores);

        foreach ($alerts as $alertData) {
            PrecessionAlert::create([
                'tenant_id' => $copropiedad->tenant_id,
                'copropiedad_id' => $copropiedad->id,
                'precession_analysis_id' => $analysis->id,
                'alert_type' => $alertData['type'],
                'severity' => $alertData['severity'],
                'title' => $alertData['title'],
                'description' => $alertData['description'],
                'probability' => $alertData['probability'] ?? null,
                'potential_impact_uf' => $alertData['impact_uf'] ?? null,
                'expected_months' => $alertData['expected_months'] ?? null,
                'recommended_actions' => $alertData['actions'] ?? [],
                'status' => 'active',
                'metadata' => $alertData['metadata'] ?? [],
            ]);
        }
    }

    /**
     * Resumir efectos para almacenamiento
     */
    protected function summarizeEffects(array $effects): array
    {
        $summary = [
            'by_type' => [],
            'by_depth' => [],
            'positive' => 0,
            'negative' => 0,
            'neutral' => 0,
        ];

        foreach ($effects as $effect) {
            $type = $effect['type'] ?? 'unknown';
            $depth = $effect['depth'] ?? 0;
            $weight = $effect['weight'] ?? 0;

            $summary['by_type'][$type] = ($summary['by_type'][$type] ?? 0) + 1;
            $summary['by_depth'][$depth] = ($summary['by_depth'][$depth] ?? 0) + 1;

            if ($weight > 0) {
                $summary['positive']++;
            } elseif ($weight < 0) {
                $summary['negative']++;
            } else {
                $summary['neutral']++;
            }
        }

        return $summary;
    }

    /**
     * Construir comparación entre análisis
     */
    protected function buildComparison(array $analyses): array
    {
        $metrics = ['precession_score', 'risk_score', 'opportunity_score', 'total_precession_value_uf'];
        $comparison = [];

        foreach ($metrics as $metric) {
            $values = array_map(fn($a) => $a->$metric ?? 0, $analyses);
            $comparison[$metric] = [
                'min' => min($values),
                'max' => max($values),
                'avg' => array_sum($values) / count($values),
                'values' => $values,
            ];
        }

        return $comparison;
    }

    /**
     * Calcular benchmark del grupo
     */
    protected function calculateBenchmark(array $analyses): array
    {
        return [
            'avg_precession_score' => collect($analyses)->avg('precession_score'),
            'avg_risk_score' => collect($analyses)->avg('risk_score'),
            'avg_opportunity_score' => collect($analyses)->avg('opportunity_score'),
            'total_value_uf' => collect($analyses)->sum('total_precession_value_uf'),
        ];
    }

    /**
     * Proyectar valor en un mes específico
     */
    protected function projectValueAtMonth(PrecessionAnalysis $analysis, Copropiedad $copropiedad, int $month): float
    {
        $baseValue = $analysis->total_precession_value_uf;
        $growthRate = 0.005; // 0.5% mensual base
        
        // Ajustar por contratos que vencen
        $expiringContracts = $copropiedad->contratosAntenas
            ->filter(fn($c) => $c->fecha_termino && $c->fecha_termino->diffInMonths(now()) <= $month)
            ->count();
        
        $adjustment = 1 - ($expiringContracts * 0.1);
        
        return round($baseValue * pow(1 + $growthRate, $month) * $adjustment, 2);
    }

    /**
     * Proyectar tendencia de riesgo
     */
    protected function projectRiskTrend(PrecessionAnalysis $analysis, Copropiedad $copropiedad, int $month): float
    {
        $baseRisk = $analysis->risk_score;
        
        // El riesgo tiende a aumentar con morosidad no resuelta
        $morosidadFactor = $copropiedad->unidades
            ->filter(fn($u) => $u->morosidad && $u->morosidad->meses_mora > 3)
            ->count() * 0.02;
        
        return min(100, $baseRisk + ($morosidadFactor * $month));
    }

    /**
     * Obtener eventos proyectados para una fecha
     */
    protected function getProjectedEvents(Copropiedad $copropiedad, Carbon $date): array
    {
        $events = [];

        // Contratos que vencen
        foreach ($copropiedad->contratosAntenas as $contrato) {
            if ($contrato->fecha_termino && $contrato->fecha_termino->format('Y-m') === $date->format('Y-m')) {
                $events[] = [
                    'type' => 'contract_expiry',
                    'description' => "Vence contrato antena: {$contrato->empresa_operador}",
                    'impact' => 'high',
                ];
            }
        }

        return $events;
    }

    /**
     * Resumir eventos clave de las proyecciones
     */
    protected function summarizeKeyEvents(array $projections): array
    {
        $allEvents = [];
        foreach ($projections as $projection) {
            foreach ($projection['events'] as $event) {
                $event['month'] = $projection['month'];
                $allEvents[] = $event;
            }
        }
        return $allEvents;
    }

    /**
     * Aplicar cambios de escenario a copropiedad
     */
    protected function applyScenarioChanges(Copropiedad $copropiedad, array $scenario): Copropiedad
    {
        $modified = clone $copropiedad;

        if (isset($scenario['new_antenna_contract'])) {
            // Simular nuevo contrato de antena
            $modified->contratosAntenas->push((object)[
                'canon_mensual_uf' => $scenario['new_antenna_contract']['canon_uf'],
                'estado' => 'vigente',
                'fecha_termino' => now()->addYears(5),
            ]);
        }

        if (isset($scenario['reduce_delinquency_percent'])) {
            // Simular reducción de morosidad
            foreach ($modified->unidades as $unidad) {
                if ($unidad->morosidad) {
                    $unidad->morosidad->deuda_total *= (1 - $scenario['reduce_delinquency_percent'] / 100);
                }
            }
        }

        return $modified;
    }

    /**
     * Generar recomendación basada en escenario simulado
     */
    protected function generateScenarioRecommendation(array $scenario, array $scores, array $valuation): string
    {
        $deltaValue = $valuation['total'];
        $deltaRisk = $scores['risk_score'];

        if ($deltaValue > 0 && $deltaRisk < 50) {
            return "Escenario favorable: Incrementa valor en " . number_format($deltaValue, 2) . " UF con riesgo controlado.";
        } elseif ($deltaValue > 0 && $deltaRisk >= 50) {
            return "Escenario con oportunidad pero alto riesgo. Evaluar mitigaciones.";
        } else {
            return "Escenario no recomendado: Valor negativo o riesgo excesivo.";
        }
    }

    /**
     * Obtener historial de análisis
     */
    public function getAnalysisHistory(int $copropiedadId, int $limit = 10): array
    {
        return PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
            ->where('status', 'completed')
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->map(fn($a) => [
                'id' => $a->id,
                'date' => $a->created_at->toIso8601String(),
                'scores' => [
                    'precession' => $a->precession_score,
                    'risk' => $a->risk_score,
                    'opportunity' => $a->opportunity_score,
                ],
                'value_uf' => $a->total_precession_value_uf,
                'alerts_count' => $a->alerts_count ?? 0,
            ])
            ->toArray();
    }

    /**
     * Invalidar cache de análisis
     */
    public function invalidateCache(int $copropiedadId): void
    {
        Cache::forget("pae_quick_{$copropiedadId}");
        Cache::forget("pae_full_{$copropiedadId}");
    }
}
