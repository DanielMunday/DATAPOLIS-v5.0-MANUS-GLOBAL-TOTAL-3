<?php

return [

    /*
    |--------------------------------------------------------------------------
    | DATAPOLIS Configuration
    |--------------------------------------------------------------------------
    */

    // Tributario
    'tasa_iva' => env('DATAPOLIS_TASA_IVA', 19),
    'tasa_interes_mora' => env('DATAPOLIS_TASA_INTERES_MORA', 1.5),
    'dia_vencimiento_default' => env('DATAPOLIS_DIA_VENCIMIENTO', 10),
    'porcentaje_fondo_reserva_minimo' => env('DATAPOLIS_FONDO_RESERVA_MIN', 5),

    // PAE Configuration
    'pae' => [
        'enabled' => env('PAE_ENABLED', true),
        'default_horizon' => env('PAE_DEFAULT_HORIZON', 36),
        'default_depth' => env('PAE_DEFAULT_DEPTH', 4),
        'cache_ttl' => env('PAE_CACHE_TTL', 1800),
        'agora_endpoint' => env('AGORA_ENDPOINT', 'http://localhost:8001/api'),
        'agora_api_key' => env('AGORA_API_KEY', ''),
    ],

    // SII Integration
    'sii' => [
        'ambiente' => env('SII_AMBIENTE', 'certificacion'),
        'url_certificacion' => 'https://maullin.sii.cl',
        'url_produccion' => 'https://palena.sii.cl',
        'timeout' => env('SII_TIMEOUT', 30),
    ],

    // UF
    'uf' => [
        'api_url' => env('UF_API_URL', 'https://mindicador.cl/api/uf'),
        'cache_ttl' => env('UF_CACHE_TTL', 3600),
    ],

    // Notificaciones
    'notificaciones' => [
        'dias_aviso_vencimiento' => env('DATAPOLIS_DIAS_AVISO', 5),
        'email_remitente' => env('MAIL_FROM_ADDRESS', 'noreply@datapolis.cl'),
    ],

    // Límites
    'limites' => [
        'max_upload_size' => env('DATAPOLIS_MAX_UPLOAD', 10240), // KB
        'max_copropiedades_por_tenant' => [
            'starter' => 5,
            'professional' => 50,
            'enterprise' => 999999,
        ],
    ],

];
