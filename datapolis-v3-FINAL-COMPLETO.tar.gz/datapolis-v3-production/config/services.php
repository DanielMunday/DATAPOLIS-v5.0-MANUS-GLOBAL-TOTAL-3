<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    // SII Chile
    'sii' => [
        'ambiente' => env('SII_AMBIENTE', 'certificacion'),
        'certificacion_url' => 'https://maullin.sii.cl',
        'produccion_url' => 'https://palena.sii.cl',
    ],

    // ÁGORA Integration
    'agora' => [
        'endpoint' => env('AGORA_ENDPOINT', 'http://localhost:8001/api'),
        'api_key' => env('AGORA_API_KEY'),
    ],

    // UF API
    'uf' => [
        'api_url' => env('UF_API_URL', 'https://mindicador.cl/api/uf'),
    ],

];
