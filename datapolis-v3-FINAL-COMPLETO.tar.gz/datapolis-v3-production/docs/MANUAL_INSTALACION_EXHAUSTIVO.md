# DATAPOLIS v3.0 - MANUAL DE INSTALACIÓN COMPLETO Y EXHAUSTIVO

---

# RESPUESTA OBJETIVA A LA CONSULTA

## ¿El paquete contiene TODO para la instalación completa?

**RESPUESTA: SÍ, contiene TODO el código fuente desarrollado.**

El paquete incluye absolutamente todos los archivos de código, configuración, migraciones, seeders y documentación necesarios. Durante el proceso de instalación se ejecuta `composer install` que descarga las librerías de Laravel (~80MB). Esto es el proceso estándar de cualquier aplicación PHP/Laravel.

### Lo que SÍ está incluido:
- ✅ 73 archivos PHP de la aplicación
- ✅ 32 modelos Eloquent completos
- ✅ 10 controladores API
- ✅ 6 servicios de negocio
- ✅ 4 PAE Engines nativos
- ✅ 5 middlewares
- ✅ 4 service providers
- ✅ Migración maestra (60+ tablas)
- ✅ Seeders con datos iniciales
- ✅ 100+ endpoints API
- ✅ 13 archivos de configuración
- ✅ composer.json (define dependencias)
- ✅ Instalador web y bash
- ✅ Documentación completa

### Lo que se GENERA durante instalación:
- 📦 `vendor/` - Librerías de Laravel (se genera con `composer install`)
- 📄 `.env` - Configuración local (se copia de `.env.example`)
- 🗄️ Tablas de BD - Se crean con `php artisan migrate`
- 📊 Datos iniciales - Se insertan con `php artisan db:seed`

---

# INVENTARIO COMPLETO DE ARCHIVOS

## Estructura Total del Paquete (131 archivos)

```
datapolis-v3-production/
│
├── app/                                    # CÓDIGO DE APLICACIÓN
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Controller.php              
│   │   │   └── Api/
│   │   │       └── AllControllers.php      # 10 controladores (~1,200 líneas)
│   │   └── Middleware/
│   │       ├── AllMiddlewares.php          
│   │       ├── TenantScope.php             
│   │       ├── CheckRole.php               
│   │       ├── CheckPermission.php         
│   │       └── EnsureEmailIsVerified.php   
│   │
│   ├── Models/                             # 32 MODELOS
│   │   ├── AllModels.php                   # (~1,500 líneas)
│   │   ├── Tenant.php
│   │   ├── User.php
│   │   ├── Copropiedad.php
│   │   ├── Unidad.php
│   │   ├── Copropietario.php
│   │   ├── ContratoAntena.php
│   │   ├── FacturaAntena.php
│   │   ├── DistribucionIngresoAntena.php
│   │   ├── PeriodoGasto.php
│   │   ├── GastoComun.php
│   │   ├── CategoriaGasto.php
│   │   ├── CobroUnidad.php
│   │   ├── Pago.php
│   │   ├── Morosidad.php
│   │   ├── FondoReserva.php
│   │   ├── MovimientoFondoReserva.php
│   │   ├── PlanCuenta.php
│   │   ├── PeriodoContable.php
│   │   ├── AsientoContable.php
│   │   ├── MovimientoContable.php
│   │   ├── SaldoCuenta.php
│   │   ├── CertificadoTributario.php
│   │   ├── ComplianceEvaluacion.php
│   │   ├── PrecessionAnalysis.php
│   │   ├── PrecessionAlert.php
│   │   ├── Asamblea.php
│   │   ├── Proveedor.php
│   │   ├── EspacioComun.php
│   │   ├── Comunicado.php
│   │   ├── UfHistorico.php
│   │   └── AuditLog.php
│   │
│   ├── Providers/                          # 4 PROVIDERS
│   │   ├── AppServiceProvider.php
│   │   ├── AuthServiceProvider.php
│   │   ├── EventServiceProvider.php
│   │   └── RouteServiceProvider.php
│   │
│   └── Services/                           # SERVICIOS
│       ├── AllServices.php                 # (~1,000 líneas)
│       └── PAE/
│           └── PaeEngines.php              # (~800 líneas)
│
├── bootstrap/
│   ├── app.php                             # Bootstrap Laravel 11
│   └── cache/.gitignore
│
├── config/                                 # 13 CONFIGURACIONES
│   ├── app.php
│   ├── auth.php
│   ├── cache.php
│   ├── cors.php
│   ├── database.php
│   ├── datapolis.php
│   ├── filesystems.php
│   ├── logging.php
│   ├── mail.php
│   ├── queue.php
│   ├── sanctum.php
│   ├── services.php
│   └── session.php
│
├── database/
│   ├── factories/
│   │   ├── TenantFactory.php
│   │   └── UserFactory.php
│   ├── migrations/
│   │   ├── 0001_01_01_000001_create_all_tables.php  # 60+ tablas
│   │   └── 2024_01_01_000001_create_all_tables.php
│   └── seeders/
│       ├── AllSeeders.php
│       └── DatabaseSeeder.php
│
├── docs/                                   # DOCUMENTACIÓN
│   ├── CIERRE_FINAL.md
│   ├── MASTER_PLAN.md
│   ├── PAPERS_METODOLOGICOS.md
│   ├── GUIA_INSTALACION_CPANEL.md
│   └── MANUAL_INSTALACION_COMPLETO.md
│
├── public/                                 # DIRECTORIO PÚBLICO
│   ├── index.php
│   ├── .htaccess
│   ├── install.php
│   └── storage/
│
├── resources/
│   └── views/
│       └── welcome.blade.php
│
├── routes/                                 # RUTAS
│   ├── api.php                             # 100+ endpoints
│   ├── web.php
│   └── console.php
│
├── storage/                                # ALMACENAMIENTO
│   ├── app/public/.gitignore
│   ├── framework/cache/.gitignore
│   ├── framework/sessions/.gitignore
│   ├── framework/views/.gitignore
│   └── logs/.gitignore
│
├── tests/
│   ├── TestCase.php
│   └── Feature/AuthTest.php
│
├── .env.example                            # PLANTILLA CONFIGURACIÓN
├── .gitignore
├── artisan                                 # CLI LARAVEL
├── CHECKLIST_INSTALACION.md
├── composer.json                           # DEPENDENCIAS
├── install.sh                              # SCRIPT INSTALACIÓN
├── phpunit.xml
└── README.md
```

---

# REQUISITOS DEL SERVIDOR

## Software Requerido

| Componente | Versión Mínima | Recomendada |
|------------|----------------|-------------|
| PHP | 8.2 | 8.3 |
| MySQL | 8.0 | 8.0+ |
| Composer | 2.0 | 2.7+ |
| Apache | 2.4 | 2.4+ |

## Extensiones PHP Requeridas

```
BCMath, Ctype, cURL, DOM, Fileinfo, GD, Iconv, Intl, JSON, 
Mbstring, OpenSSL, PCRE, PDO, PDO_MySQL, Session, Tokenizer, XML, Zip
```

---

# INSTALACIÓN EN SERVIDOR LOCAL

## Windows (Laragon)

```batch
REM PASO 1: Instalar Laragon de https://laragon.org

REM PASO 2: Extraer paquete en C:\laragon\www\datapolis

REM PASO 3: Abrir Terminal Laragon y ejecutar:
cd C:\laragon\www\datapolis
composer install
copy .env.example .env
php artisan key:generate

REM PASO 4: Crear BD "datapolis" en HeidiSQL

REM PASO 5: Editar .env con credenciales

REM PASO 6: Migraciones
php artisan migrate --force
php artisan db:seed --force

REM PASO 7: Iniciar
php artisan serve

REM PASO 8: Acceder a http://localhost:8000
```

## Linux (Ubuntu)

```bash
# PASO 1: Instalar dependencias
sudo apt install php8.3 php8.3-mysql php8.3-mbstring php8.3-xml \
    php8.3-bcmath php8.3-curl php8.3-gd php8.3-intl php8.3-zip \
    mysql-server composer apache2 libapache2-mod-php8.3

# PASO 2: Extraer y configurar
cd /var/www
sudo tar -xzvf datapolis-v3-FINAL-COMPLETO.tar.gz
sudo mv datapolis-v3-production datapolis
cd datapolis
sudo chown -R www-data:www-data .
sudo chmod -R 755 storage bootstrap/cache

# PASO 3: Instalar dependencias
composer install

# PASO 4: Configurar
cp .env.example .env
php artisan key:generate

# PASO 5: Crear BD
sudo mysql -e "CREATE DATABASE datapolis; CREATE USER 'datapolis'@'localhost' IDENTIFIED BY 'password'; GRANT ALL ON datapolis.* TO 'datapolis'@'localhost';"

# PASO 6: Editar .env con credenciales

# PASO 7: Migraciones
php artisan migrate --force
php artisan db:seed --force

# PASO 8: Optimizar
php artisan config:cache
php artisan route:cache
php artisan storage:link
```

## macOS

```bash
# PASO 1: Instalar Homebrew, PHP, MySQL
brew install php@8.3 mysql composer
brew services start mysql

# PASO 2-8: Igual que Linux
```

---

# INSTALACIÓN EN cPANEL

## Con Acceso SSH (Recomendado)

```bash
# PASO 1: Conectar SSH
ssh usuario@tudominio.com

# PASO 2: Navegar y extraer
cd ~/public_html
tar -xzvf datapolis-v3-FINAL-COMPLETO.tar.gz
mv datapolis-v3-production datapolis
cd datapolis

# PASO 3: Instalar dependencias
composer install --no-dev --optimize-autoloader

# PASO 4: Configurar
cp .env.example .env
nano .env
# Editar:
# APP_URL=https://tudominio.com
# DB_DATABASE=usuario_datapolis
# DB_USERNAME=usuario_datapolis
# DB_PASSWORD=tupassword

# PASO 5: Generar key y migrar
php artisan key:generate
php artisan migrate --force
php artisan db:seed --force

# PASO 6: Optimizar
php artisan config:cache
php artisan route:cache
php artisan storage:link
chmod -R 755 storage bootstrap/cache

# PASO 7: Configurar Document Root en cPanel
# Dominios > tudominio.com > Document Root: public_html/datapolis/public

# PASO 8: Configurar Cron
# * * * * * cd ~/public_html/datapolis && php artisan schedule:run >> /dev/null 2>&1
```

## Sin Acceso SSH (Solo File Manager)

```
PASO 1: Crear BD en cPanel > MySQL Databases

PASO 2: Subir datapolis-v3-FINAL-COMPLETO.tar.gz via File Manager

PASO 3: Extraer en public_html

PASO 4: Subir vendor.zip pre-generado (si no hay terminal)
        O usar terminal web de cPanel para: composer install

PASO 5: Copiar .env.example a .env y editar con credenciales

PASO 6: Acceder a https://tudominio.com/install.php
        Seguir asistente de 4 pasos

PASO 7: Configurar Document Root a /public

PASO 8: Configurar Cron Job

PASO 9: ELIMINAR install.php
```

---

# VERIFICACIÓN POST-INSTALACIÓN

## Checklist

```
□ URL principal carga
□ Login funciona (admin@datapolis.cl / DataPolis2024!)
□ API responde en /api/v1/health
□ Crear copropiedad de prueba
□ SSL activo
□ Cron configurado
□ install.php eliminado
□ APP_DEBUG=false
□ Contraseña cambiada
```

## Comandos de Verificación

```bash
php artisan about              # Estado de la app
php artisan route:list         # Rutas registradas
php artisan migrate:status     # Estado migraciones
php artisan schedule:list      # Tareas programadas
```

---

# CREDENCIALES INICIALES

```
Email: admin@datapolis.cl
Password: DataPolis2024!

⚠️ CAMBIAR INMEDIATAMENTE DESPUÉS DEL PRIMER LOGIN
```

---

# SOLUCIÓN DE PROBLEMAS

| Error | Causa | Solución |
|-------|-------|----------|
| 500 Internal | Permisos/Config | `chmod -R 755 storage`, verificar .env |
| BD Connection | Credenciales | Verificar DB_* en .env |
| Blank Page | PHP Error | APP_DEBUG=true, revisar logs |
| Memory Limit | Composer | `php -d memory_limit=-1 composer install` |

---

# RESUMEN

**El paquete `datapolis-v3-FINAL-COMPLETO.tar.gz` contiene TODO el código necesario.**

La instalación requiere ejecutar:
1. `composer install` (descarga librerías Laravel)
2. Configurar `.env`
3. `php artisan migrate` (crea tablas)
4. `php artisan db:seed` (datos iniciales)

Esto es el proceso estándar de cualquier aplicación Laravel.

**Tiempo estimado de instalación:**
- Servidor local: 15-30 minutos
- cPanel con SSH: 20-40 minutos
- cPanel sin SSH: 30-60 minutos

---

DATAPOLIS v3.0 | Febrero 2026
