<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return response()->json([
        'application' => 'DATAPOLIS',
        'version' => '3.0.0',
        'status' => 'running',
        'api_endpoint' => url('/api/v1'),
        'documentation' => url('/api/documentation'),
    ]);
});

Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'timestamp' => now()->toIso8601String(),
        'database' => 'connected',
        'cache' => 'active',
    ]);
});

// Verificación de certificados (público)
Route::get('/certificados/verificar/{codigo}', function ($codigo) {
    $certificado = \App\Models\CertificadoTributario::where('codigo_verificacion', $codigo)->first();
    
    if (!$certificado) {
        return response()->json(['valido' => false, 'mensaje' => 'Certificado no encontrado'], 404);
    }
    
    if ($certificado->estado === 'anulado') {
        return response()->json(['valido' => false, 'mensaje' => 'Certificado anulado']);
    }
    
    if ($certificado->fecha_vigencia < now()) {
        return response()->json(['valido' => false, 'mensaje' => 'Certificado vencido']);
    }
    
    return response()->json([
        'valido' => true,
        'tipo' => $certificado->tipo,
        'folio' => $certificado->folio,
        'fecha_emision' => $certificado->fecha_emision,
        'fecha_vigencia' => $certificado->fecha_vigencia,
    ]);
});
