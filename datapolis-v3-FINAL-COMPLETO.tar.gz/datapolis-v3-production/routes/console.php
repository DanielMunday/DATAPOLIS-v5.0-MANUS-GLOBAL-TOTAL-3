<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

/*
|--------------------------------------------------------------------------
| Console Routes
|--------------------------------------------------------------------------
*/

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote')->hourly();

/*
|--------------------------------------------------------------------------
| Scheduled Tasks - DATAPOLIS
|--------------------------------------------------------------------------
*/

// Sincronizar valor UF diariamente a las 8:00
Schedule::call(function () {
    $response = \Illuminate\Support\Facades\Http::get('https://mindicador.cl/api/uf');
    if ($response->successful()) {
        $data = $response->json();
        $uf = $data['serie'][0];
        \App\Models\UfHistorico::updateOrCreate(
            ['fecha' => \Carbon\Carbon::parse($uf['fecha'])->toDateString()],
            ['valor' => $uf['valor']]
        );
    }
})->dailyAt('08:00')->name('sync-uf')->withoutOverlapping();

// Facturación automática de antenas - día 1 de cada mes a las 00:01
Schedule::call(function () {
    $periodo = now()->format('Y-m');
    $copropiedades = \App\Models\Copropiedad::whereHas('contratosAntenas', function ($q) {
        $q->where('estado', 'vigente');
    })->get();
    
    foreach ($copropiedades as $copropiedad) {
        try {
            app(\App\Services\AntenasFacturacionService::class)->facturarPeriodo($copropiedad->id, $periodo);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error facturando antenas', [
                'copropiedad_id' => $copropiedad->id,
                'error' => $e->getMessage()
            ]);
        }
    }
})->monthlyOn(1, '00:01')->name('facturar-antenas')->withoutOverlapping();

// Calcular intereses de mora diariamente a las 06:00
Schedule::call(function () {
    $unidadesMorosas = \App\Models\Morosidad::where('deuda_total', '>', 0)->get();
    
    foreach ($unidadesMorosas as $morosidad) {
        try {
            app(\App\Services\GastosComunesService::class)->actualizarMorosidad($morosidad->unidad_id);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error calculando intereses', [
                'unidad_id' => $morosidad->unidad_id,
                'error' => $e->getMessage()
            ]);
        }
    }
})->dailyAt('06:00')->name('calcular-intereses')->withoutOverlapping();

// Evaluación de compliance semanal - domingos a las 02:00
Schedule::call(function () {
    $copropiedades = \App\Models\Copropiedad::where('activa', true)->get();
    
    foreach ($copropiedades as $copropiedad) {
        try {
            app(\App\Services\ComplianceService::class)->evaluarCopropiedad($copropiedad->id);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error en evaluación compliance', [
                'copropiedad_id' => $copropiedad->id,
                'error' => $e->getMessage()
            ]);
        }
    }
})->weeklyOn(0, '02:00')->name('evaluar-compliance')->withoutOverlapping();

// Limpieza de cache diaria a las 03:00
Schedule::command('cache:prune-stale-tags')->dailyAt('03:00');

// Limpieza de tokens expirados semanal
Schedule::command('sanctum:prune-expired --hours=168')->weekly();

// Backup de base de datos diario (si está configurado)
Schedule::command('backup:run --only-db')->dailyAt('04:00')->environments(['production']);
