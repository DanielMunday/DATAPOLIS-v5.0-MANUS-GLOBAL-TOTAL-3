<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - PAE M11 - RUTAS API
 * Endpoints del Motor de Análisis Precesional
 * =========================================================================
 * 
 * Este archivo define todas las rutas API para el módulo PAE.
 * Debe ser incluido en routes/api.php
 */

use App\Http\Controllers\Api\PrecessionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| PAE (Precession Analysis Engine) Routes
|--------------------------------------------------------------------------
|
| Prefix: /api/v1/pae
| Middleware: auth:sanctum, tenant
|
*/

Route::prefix('pae')->middleware(['auth:sanctum', 'tenant'])->group(function () {
    
    // =========================================================================
    // DASHBOARD GENERAL
    // =========================================================================
    
    /**
     * GET /api/v1/pae/dashboard
     * Dashboard general del motor PAE
     * - Estadísticas de alertas activas
     * - Valor total del portafolio
     * - Scores promedio
     * - Análisis por copropiedad
     */
    Route::get('dashboard', [PrecessionController::class, 'dashboard']);

    // =========================================================================
    // ALERTAS GLOBALES
    // =========================================================================
    
    /**
     * GET /api/v1/pae/alerts
     * Listar todas las alertas activas del tenant
     * Query params: severity, status, per_page
     */
    Route::get('alerts', [PrecessionController::class, 'alerts']);
    
    /**
     * GET /api/v1/pae/alerts/{id}
     * Detalle de una alerta específica
     */
    Route::get('alerts/{id}', [PrecessionController::class, 'alertDetail']);
    
    /**
     * PUT /api/v1/pae/alerts/{id}/acknowledge
     * Reconocer una alerta (marcar como vista)
     */
    Route::put('alerts/{id}/acknowledge', [PrecessionController::class, 'acknowledgeAlert']);
    
    /**
     * PUT /api/v1/pae/alerts/{id}/resolve
     * Resolver una alerta
     * Body: { resolution_notes: string }
     */
    Route::put('alerts/{id}/resolve', [PrecessionController::class, 'resolveAlert']);
    
    /**
     * PUT /api/v1/pae/alerts/{id}/dismiss
     * Descartar una alerta
     * Body: { reason: string }
     */
    Route::put('alerts/{id}/dismiss', [PrecessionController::class, 'dismissAlert']);

    // =========================================================================
    // COMPARACIONES Y BENCHMARK
    // =========================================================================
    
    /**
     * POST /api/v1/pae/compare
     * Comparar análisis de múltiples copropiedades
     * Body: { copropiedad_ids: [1, 2, 3] }
     */
    Route::post('compare', [PrecessionController::class, 'compare']);
    
    /**
     * GET /api/v1/pae/benchmark
     * Obtener benchmark del portafolio
     */
    Route::get('benchmark', [PrecessionController::class, 'benchmark']);

    // =========================================================================
    // ONTOLOGÍA (Solo lectura)
    // =========================================================================
    
    /**
     * GET /api/v1/pae/ontology/nodes
     * Listar tipos de nodos de la ontología
     */
    Route::get('ontology/nodes', [PrecessionController::class, 'ontologyNodes']);
    
    /**
     * GET /api/v1/pae/ontology/edges
     * Listar tipos de aristas de la ontología
     */
    Route::get('ontology/edges', [PrecessionController::class, 'ontologyEdges']);

    // =========================================================================
    // CONFIGURACIÓN
    // =========================================================================
    
    /**
     * GET /api/v1/pae/config
     * Obtener configuración actual del PAE
     */
    Route::get('config', [PrecessionController::class, 'getConfig']);
    
    /**
     * PUT /api/v1/pae/config
     * Actualizar configuración del PAE (admin only)
     */
    Route::put('config', [PrecessionController::class, 'updateConfig'])
        ->middleware('permission:pae.config');

});

/*
|--------------------------------------------------------------------------
| PAE Routes por Copropiedad
|--------------------------------------------------------------------------
|
| Prefix: /api/v1/copropiedades/{copropiedadId}/pae
| Middleware: auth:sanctum, tenant
|
*/

Route::prefix('copropiedades/{copropiedadId}/pae')
    ->middleware(['auth:sanctum', 'tenant'])
    ->group(function () {

    // =========================================================================
    // ANÁLISIS
    // =========================================================================
    
    /**
     * POST /api/v1/copropiedades/{id}/pae/analyze
     * Ejecutar análisis precesional completo
     * Body: { horizon: 36, depth: 4, type: 'full', force_refresh: false }
     */
    Route::post('analyze', [PrecessionController::class, 'analyze']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/quick
     * Análisis rápido (cached)
     */
    Route::get('quick', [PrecessionController::class, 'quickAnalysis']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/history
     * Historial de análisis
     * Query params: limit
     */
    Route::get('history', [PrecessionController::class, 'history']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/latest
     * Último análisis completado
     */
    Route::get('latest', [PrecessionController::class, 'latestAnalysis']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/{analysisId}
     * Detalle de un análisis específico
     */
    Route::get('{analysisId}', [PrecessionController::class, 'showAnalysis']);

    // =========================================================================
    // PROYECCIONES
    // =========================================================================
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/projection
     * Proyección temporal de efectos
     * Query params: months (default 12)
     */
    Route::get('projection', [PrecessionController::class, 'projection']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/trends
     * Tendencias históricas
     */
    Route::get('trends', [PrecessionController::class, 'trends']);

    // =========================================================================
    // SIMULACIONES
    // =========================================================================
    
    /**
     * POST /api/v1/copropiedades/{id}/pae/simulate
     * Simular escenario what-if
     * Body: {
     *   scenario: {
     *     new_antenna_contract: { canon_uf: 50 },
     *     reduce_delinquency_percent: 30,
     *     reserve_fund_increase_uf: 100
     *   }
     * }
     */
    Route::post('simulate', [PrecessionController::class, 'simulate']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/simulations
     * Historial de simulaciones
     */
    Route::get('simulations', [PrecessionController::class, 'simulationHistory']);

    // =========================================================================
    // ALERTAS POR COPROPIEDAD
    // =========================================================================
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/alerts
     * Alertas activas de la copropiedad
     */
    Route::get('alerts', [PrecessionController::class, 'copropiedadAlerts']);

    // =========================================================================
    // GRAFO Y ONTOLOGÍA
    // =========================================================================
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/graph
     * Obtener grafo ontológico de la copropiedad
     * Para visualización en frontend
     */
    Route::get('graph', [PrecessionController::class, 'getGraph']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/effects
     * Listar efectos del último análisis
     * Query params: type, depth, min_weight
     */
    Route::get('effects', [PrecessionController::class, 'getEffects']);

    // =========================================================================
    // VALORACIÓN
    // =========================================================================
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/valuation
     * Valoración precesional detallada
     */
    Route::get('valuation', [PrecessionController::class, 'getValuation']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/investment-score
     * Score de inversión para potenciales inversionistas
     */
    Route::get('investment-score', [PrecessionController::class, 'investmentScore']);

    // =========================================================================
    // REPORTES
    // =========================================================================
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/report
     * Generar reporte PDF de análisis
     */
    Route::get('report', [PrecessionController::class, 'generateReport']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/export
     * Exportar datos de análisis (Excel/CSV)
     * Query params: format (xlsx, csv)
     */
    Route::get('export', [PrecessionController::class, 'exportData']);

    // =========================================================================
    // CACHE
    // =========================================================================
    
    /**
     * DELETE /api/v1/copropiedades/{id}/pae/cache
     * Invalidar cache de análisis
     */
    Route::delete('cache', [PrecessionController::class, 'invalidateCache']);

    // =========================================================================
    // INTEGRACIÓN ÁGORA
    // =========================================================================
    
    /**
     * POST /api/v1/copropiedades/{id}/pae/sync-agora
     * Sincronizar con ÁGORA manualmente
     */
    Route::post('sync-agora', [PrecessionController::class, 'syncWithAgora']);
    
    /**
     * GET /api/v1/copropiedades/{id}/pae/territorial-data
     * Obtener datos territoriales de ÁGORA
     */
    Route::get('territorial-data', [PrecessionController::class, 'getTerritorialData']);

});

/*
|--------------------------------------------------------------------------
| Webhooks PAE (para ÁGORA)
|--------------------------------------------------------------------------
|
| Prefix: /api/v1/pae/webhooks
| Sin autenticación de usuario, usa API key
|
*/

Route::prefix('pae/webhooks')->middleware('api.key')->group(function () {
    
    /**
     * POST /api/v1/pae/webhooks/agora-update
     * Recibir actualizaciones de ÁGORA
     */
    Route::post('agora-update', [PrecessionController::class, 'handleAgoraWebhook']);
    
    /**
     * POST /api/v1/pae/webhooks/territorial-change
     * Notificación de cambio territorial
     */
    Route::post('territorial-change', [PrecessionController::class, 'handleTerritorialChange']);

});
