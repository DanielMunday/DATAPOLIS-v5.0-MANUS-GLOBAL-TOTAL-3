<?php
/**
 * DATAPOLIS v3.0 - INSTALADOR WEB
 * Para cPanel sin acceso SSH
 * 
 * INSTRUCCIONES:
 * 1. Sube este archivo a public/install.php
 * 2. Accede desde el navegador: https://tudominio.com/install.php
 * 3. Sigue las instrucciones
 * 4. ELIMINA este archivo después de la instalación
 */

// Prevenir acceso en producción si ya está instalado
if (file_exists(__DIR__ . '/../.installed') && !isset($_GET['force'])) {
    die('Sistema ya instalado. Elimina el archivo .installed para reinstalar.');
}

$basePath = dirname(__DIR__);
$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Funciones helper
function checkRequirement($name, $check, $required = true) {
    global $errors;
    if (!$check && $required) {
        $errors[] = $name;
        return false;
    }
    return true;
}

function runArtisan($command) {
    global $basePath;
    $output = [];
    $return = 0;
    exec("cd {$basePath} && php artisan {$command} 2>&1", $output, $return);
    return ['output' => implode("\n", $output), 'success' => $return === 0];
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATAPOLIS v3.0 - Instalador</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; color: #333; line-height: 1.6; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 30px; margin-bottom: 20px; }
        h1 { color: #2563eb; margin-bottom: 10px; }
        h2 { color: #1e40af; margin-bottom: 15px; font-size: 1.3em; }
        .steps { display: flex; gap: 10px; margin-bottom: 30px; }
        .step { flex: 1; padding: 10px; text-align: center; background: #e5e7eb; border-radius: 4px; }
        .step.active { background: #2563eb; color: white; }
        .step.done { background: #10b981; color: white; }
        .check { display: flex; align-items: center; padding: 10px; margin: 5px 0; border-radius: 4px; }
        .check.ok { background: #d1fae5; color: #065f46; }
        .check.error { background: #fee2e2; color: #991b1b; }
        .check.warning { background: #fef3c7; color: #92400e; }
        .btn { display: inline-block; padding: 12px 24px; background: #2563eb; color: white; text-decoration: none; border-radius: 6px; border: none; cursor: pointer; font-size: 16px; }
        .btn:hover { background: #1d4ed8; }
        .btn.success { background: #10b981; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 500; }
        input, select { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 4px; font-size: 14px; }
        .alert { padding: 15px; border-radius: 4px; margin-bottom: 15px; }
        .alert.success { background: #d1fae5; color: #065f46; border: 1px solid #10b981; }
        .alert.error { background: #fee2e2; color: #991b1b; border: 1px solid #ef4444; }
        pre { background: #1f2937; color: #f9fafb; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 12px; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>🏢 DATAPOLIS v3.0</h1>
        <p>Sistema de Administración de Copropiedades</p>
    </div>

    <div class="steps">
        <div class="step <?= $step == 1 ? 'active' : ($step > 1 ? 'done' : '') ?>">1. Requisitos</div>
        <div class="step <?= $step == 2 ? 'active' : ($step > 2 ? 'done' : '') ?>">2. Base de Datos</div>
        <div class="step <?= $step == 3 ? 'active' : ($step > 3 ? 'done' : '') ?>">3. Instalación</div>
        <div class="step <?= $step == 4 ? 'active' : '' ?>">4. Finalizar</div>
    </div>

    <?php if ($step == 1): ?>
    <!-- PASO 1: Verificar Requisitos -->
    <div class="card">
        <h2>Verificación de Requisitos</h2>
        
        <?php
        $phpVersion = PHP_VERSION;
        $phpOk = version_compare($phpVersion, '8.2.0', '>=');
        $extensions = ['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'bcmath', 'fileinfo'];
        $allExtensions = true;
        
        foreach ($extensions as $ext) {
            if (!extension_loaded($ext)) {
                $allExtensions = false;
                break;
            }
        }
        
        $storageWritable = is_writable($basePath . '/storage');
        $bootstrapWritable = is_writable($basePath . '/bootstrap/cache');
        $envExists = file_exists($basePath . '/.env');
        $composerInstalled = file_exists($basePath . '/vendor/autoload.php');
        ?>
        
        <div class="check <?= $phpOk ? 'ok' : 'error' ?>">
            <?= $phpOk ? '✓' : '✗' ?> PHP Version: <?= $phpVersion ?> (Requerido: 8.2+)
        </div>
        
        <div class="check <?= $allExtensions ? 'ok' : 'error' ?>">
            <?= $allExtensions ? '✓' : '✗' ?> Extensiones PHP requeridas
        </div>
        
        <div class="check <?= $storageWritable ? 'ok' : 'error' ?>">
            <?= $storageWritable ? '✓' : '✗' ?> Directorio storage/ escribible
        </div>
        
        <div class="check <?= $bootstrapWritable ? 'ok' : 'error' ?>">
            <?= $bootstrapWritable ? '✓' : '✗' ?> Directorio bootstrap/cache/ escribible
        </div>
        
        <div class="check <?= $envExists ? 'ok' : 'warning' ?>">
            <?= $envExists ? '✓' : '!' ?> Archivo .env <?= $envExists ? 'existe' : 'no existe (se creará)' ?>
        </div>
        
        <div class="check <?= $composerInstalled ? 'ok' : 'error' ?>">
            <?= $composerInstalled ? '✓' : '✗' ?> Dependencias Composer instaladas
        </div>
        
        <?php if (!$composerInstalled): ?>
        <div class="alert error">
            <strong>Acción requerida:</strong> Ejecuta <code>composer install</code> en el servidor antes de continuar.
        </div>
        <?php endif; ?>
        
        <?php if ($phpOk && $allExtensions && $storageWritable && $bootstrapWritable && $composerInstalled): ?>
        <br>
        <a href="?step=2" class="btn">Continuar →</a>
        <?php else: ?>
        <br>
        <p style="color: #991b1b;">Corrige los errores antes de continuar.</p>
        <?php endif; ?>
    </div>
    
    <?php elseif ($step == 2): ?>
    <!-- PASO 2: Configuración de Base de Datos -->
    <div class="card">
        <h2>Configuración de Base de Datos</h2>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dbHost = $_POST['db_host'] ?? 'localhost';
            $dbPort = $_POST['db_port'] ?? '3306';
            $dbName = $_POST['db_name'] ?? '';
            $dbUser = $_POST['db_user'] ?? '';
            $dbPass = $_POST['db_pass'] ?? '';
            
            // Probar conexión
            try {
                $pdo = new PDO("mysql:host={$dbHost};port={$dbPort};dbname={$dbName}", $dbUser, $dbPass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // Actualizar .env
                $envContent = file_get_contents($basePath . '/.env.example');
                $envContent = preg_replace('/DB_HOST=.*/', "DB_HOST={$dbHost}", $envContent);
                $envContent = preg_replace('/DB_PORT=.*/', "DB_PORT={$dbPort}", $envContent);
                $envContent = preg_replace('/DB_DATABASE=.*/', "DB_DATABASE={$dbName}", $envContent);
                $envContent = preg_replace('/DB_USERNAME=.*/', "DB_USERNAME={$dbUser}", $envContent);
                $envContent = preg_replace('/DB_PASSWORD=.*/', "DB_PASSWORD={$dbPass}", $envContent);
                
                file_put_contents($basePath . '/.env', $envContent);
                
                echo '<div class="alert success">✓ Conexión exitosa. Archivo .env actualizado.</div>';
                echo '<a href="?step=3" class="btn success">Continuar →</a>';
                
            } catch (PDOException $e) {
                echo '<div class="alert error">Error de conexión: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
        ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Host de Base de Datos</label>
                <input type="text" name="db_host" value="localhost" required>
            </div>
            <div class="form-group">
                <label>Puerto</label>
                <input type="text" name="db_port" value="3306" required>
            </div>
            <div class="form-group">
                <label>Nombre de Base de Datos</label>
                <input type="text" name="db_name" placeholder="datapolis" required>
            </div>
            <div class="form-group">
                <label>Usuario</label>
                <input type="text" name="db_user" required>
            </div>
            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="db_pass">
            </div>
            <button type="submit" class="btn">Probar Conexión</button>
        </form>
    </div>
    
    <?php elseif ($step == 3): ?>
    <!-- PASO 3: Instalación -->
    <div class="card">
        <h2>Instalación</h2>
        
        <?php
        $actions = [];
        
        // Generar key
        $result = runArtisan('key:generate --force');
        $actions[] = ['name' => 'Generar Application Key', 'success' => $result['success'], 'output' => $result['output']];
        
        // Migraciones
        $result = runArtisan('migrate --force');
        $actions[] = ['name' => 'Ejecutar Migraciones', 'success' => $result['success'], 'output' => $result['output']];
        
        // Seeders
        $result = runArtisan('db:seed --force');
        $actions[] = ['name' => 'Ejecutar Seeders', 'success' => $result['success'], 'output' => $result['output']];
        
        // Cache
        $result = runArtisan('config:cache');
        $actions[] = ['name' => 'Cachear Configuración', 'success' => $result['success'], 'output' => $result['output']];
        
        $result = runArtisan('route:cache');
        $actions[] = ['name' => 'Cachear Rutas', 'success' => $result['success'], 'output' => $result['output']];
        
        $allSuccess = true;
        foreach ($actions as $action):
            if (!$action['success']) $allSuccess = false;
        ?>
        <div class="check <?= $action['success'] ? 'ok' : 'error' ?>">
            <?= $action['success'] ? '✓' : '✗' ?> <?= $action['name'] ?>
            <?php if (!$action['success']): ?>
            <pre style="margin-top: 10px;"><?= htmlspecialchars($action['output']) ?></pre>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        
        <?php if ($allSuccess): ?>
        <br>
        <a href="?step=4" class="btn success">Finalizar →</a>
        <?php else: ?>
        <br>
        <p style="color: #991b1b;">Hubo errores. Revisa los logs y corrige antes de continuar.</p>
        <a href="?step=3" class="btn">Reintentar</a>
        <?php endif; ?>
    </div>
    
    <?php elseif ($step == 4): ?>
    <!-- PASO 4: Finalizar -->
    <div class="card">
        <h2>✓ Instalación Completada</h2>
        
        <?php
        // Marcar como instalado
        file_put_contents($basePath . '/.installed', date('Y-m-d H:i:s'));
        ?>
        
        <div class="alert success">
            <strong>¡DATAPOLIS v3.0 instalado correctamente!</strong>
        </div>
        
        <h3 style="margin: 20px 0 10px;">Credenciales de Acceso:</h3>
        <pre>
Email: admin@datapolis.cl
Password: DataPolis2024!
        </pre>
        
        <h3 style="margin: 20px 0 10px;">Próximos pasos:</h3>
        <ol style="margin-left: 20px;">
            <li>Elimina este archivo (install.php) por seguridad</li>
            <li>Configura el cron job para el scheduler</li>
            <li>Configura SSL si no lo tienes</li>
            <li>Cambia la contraseña del admin</li>
        </ol>
        
        <h3 style="margin: 20px 0 10px;">Cron Job:</h3>
        <pre>* * * * * cd <?= $basePath ?> && php artisan schedule:run >> /dev/null 2>&1</pre>
        
        <br>
        <a href="/" class="btn success">Ir a DATAPOLIS →</a>
    </div>
    <?php endif; ?>
    
    <div class="card" style="text-align: center; padding: 15px;">
        <small>DATAPOLIS v3.0 © 2026 - Sistema de Administración de Copropiedades</small>
    </div>
</div>
</body>
</html>
