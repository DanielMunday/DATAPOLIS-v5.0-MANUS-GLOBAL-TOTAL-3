<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATAPOLIS v3.0</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .container {
            text-align: center;
            padding: 40px;
        }
        .logo {
            font-size: 4rem;
            margin-bottom: 20px;
        }
        h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            font-weight: 300;
        }
        .version {
            font-size: 1.2rem;
            opacity: 0.8;
            margin-bottom: 30px;
        }
        .description {
            font-size: 1.1rem;
            max-width: 600px;
            margin: 0 auto 40px;
            line-height: 1.8;
            opacity: 0.9;
        }
        .buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn {
            display: inline-block;
            padding: 15px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .btn-primary {
            background: white;
            color: #1e3a8a;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.1);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
        }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            max-width: 800px;
            margin: 50px auto 0;
        }
        .feature {
            background: rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 12px;
            backdrop-filter: blur(10px);
        }
        .feature-icon {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .feature h3 {
            margin-bottom: 8px;
            font-size: 1.1rem;
        }
        .feature p {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        .status {
            margin-top: 50px;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            display: inline-block;
        }
        .status-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 5px 0;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #10b981;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🏢</div>
        <h1>DATAPOLIS</h1>
        <div class="version">v3.0 - Ecosistema PropTech/FinTech/RegTech</div>
        
        <p class="description">
            Sistema integral de administración de copropiedades para Chile.
            Cumplimiento Ley 21.442, DS 7/2025 y normativa SII.
            23 módulos integrados con motor de análisis precesional (PAE).
        </p>
        
        <div class="buttons">
            <a href="/api/v1/auth/login" class="btn btn-primary">Acceder al Sistema</a>
            <a href="/api/documentation" class="btn btn-secondary">Documentación API</a>
        </div>
        
        <div class="features">
            <div class="feature">
                <div class="feature-icon">📊</div>
                <h3>Gastos Comunes</h3>
                <p>Prorrateo automático, cobranza y morosidad</p>
            </div>
            <div class="feature">
                <div class="feature-icon">📡</div>
                <h3>Antenas</h3>
                <p>Gestión de contratos y facturación SII</p>
            </div>
            <div class="feature">
                <div class="feature-icon">📈</div>
                <h3>Contabilidad</h3>
                <p>Completa por copropiedad con estados financieros</p>
            </div>
            <div class="feature">
                <div class="feature-icon">✅</div>
                <h3>Compliance</h3>
                <p>Evaluación automática de cumplimiento</p>
            </div>
        </div>
        
        <div class="status">
            <div class="status-item">
                <span class="status-dot"></span>
                <span>Sistema operativo</span>
            </div>
            <div class="status-item">
                <span class="status-dot"></span>
                <span>API disponible</span>
            </div>
            <div class="status-item">
                <span class="status-dot"></span>
                <span>Base de datos conectada</span>
            </div>
        </div>
    </div>
</body>
</html>
